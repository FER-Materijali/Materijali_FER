﻿using System.Diagnostics;
using System.Windows;
using SocialNetworkLibrary;

namespace SocialNetworkingClientWPF
{
    /// <summary>
    /// Interaction logic for TwitterAuth.xaml
    /// </summary>
    public partial class TwitterAuth : Window
    {
        public TwitterAuth()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txtPIN.Focus();
        }

        private void statusBar_Loaded(object sender, RoutedEventArgs e)
        {
            using (new StatusBusy(statusBarText, "Opening authorization URL..."))
            {
                openAuthorizationURL();
            }
        }

        private void openAuthorizationURL()
        {
            string authorizationURI = TwitterProvider.Instance.AuthorizationURL;
            ProcessStartInfo sInfo = new ProcessStartInfo(authorizationURI);
            Process.Start(sInfo);
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            string pin = txtPIN.Text;
            bool authorizationOk = TwitterProvider.Instance.AuthorizeUser(pin);

            if (authorizationOk)
            {
                MessageBox.Show("Authorization succeded.",
                    "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Wrong pin!",
                    "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            Close();
        }
    }
}
