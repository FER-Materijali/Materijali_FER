﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using PPIJServicesLibrary;
using SocialNetworkLibrary;
using Sorters;

namespace SocialNetworkingClientWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, IMessageForm
    {
        #region IMessageForm interface

        public string Author
        {
            get { return txtAuthor.Text; }
        }

        public string MessageBody
        {
            get { return txtMessageBody.Text; }
        }

        public string Reply
        {
            get { return txtReply.Text; }
        }

        /// <summary>
        ///     Registers a new social network to this form.
        /// </summary>
        public void RegisterNetwork(SocialNetwork network)
        {
            if (SocialNetworks.Contains(network))
            {
                throw new Exception(network.Name +
                    " is already registered to this form.");
            }
            SocialNetworks.Add(network);
        }

        #endregion

        /// <summary>
        ///     Collection of social networks registered to
        ///     this form.
        /// </summary>
        public IList<SocialNetwork> SocialNetworks { get; set; }

        /// <summary>
        ///     Collection of users to display on the form.
        /// </summary>
        public IList<UserProfile> Users { get; set; }

        /// <summary>
        ///     Collection of all users from all social networks.
        /// </summary>
        /// <remarks>
        ///     This collection is not automatically updated if the list
        ///     of users from a social network changes during the runtime 
        ///     of this application.
        /// </remarks>
        private IList<UserProfile> allUsers { get; set; }

        /// <summary>
        ///     True if the message can be send to a network.
        /// </summary>
        public bool sendEnabled
        {
            get
            {
                bool messageBodyHasText = !string.IsNullOrEmpty(txtMessageBody.Text);
                bool atLeastOneNetworkIsSelected =
                    checkedListBoxSocialNetworks.SelectedItems.Count > 0;

                return messageBodyHasText && atLeastOneNetworkIsSelected;
            }
        }

        /// <summary>
        ///     If true, displays the string 'Search users' in the 
        ///     search text box.
        /// </summary>
        private bool displaySearchUsersInTextbox;


        public MainWindow()
        {
            SocialNetworks = new List<SocialNetwork>();
            allUsers = new List<UserProfile>();
            Users = new List<UserProfile>();

            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            new PPiJBoard(this);
            new Twitter(this);
            new Facebook(this);

            setBindings();
            setLateBindings();

            displaySearchUsersInTextbox = true;
            ignoreTextChanged = false;
        }

        /// <summary>
        ///     Binds the socialNetworks collection to the 
        ///     checkedListBoxSocialNetworks component.
        /// </summary>
        private void setBindings()
        {
            checkedListBoxSocialNetworks.ItemsSource = SocialNetworks;
        }

        /// <summary>
        ///     Binds the users listbox to all users from all registered
        ///     social networks.
        /// </summary>
        /// <remarks>
        ///     Getting all users can be expensive.
        /// </remarks>
        private void setLateBindings()
        {
             new Thread(() => 
                {
                    listBoxUsers.Dispatcher.Invoke(
                        DispatcherPriority.Normal,
                        new Action(() =>
                            {
                                getAllUsers();
                                listBoxUsers.ItemsSource = allUsers.MergeSort();
                            }
                    ));
                }
            ).Start();
        }

        /// <summary>
        ///     Adds users to the collection of social
        ///     network users.
        /// </summary>
        /// <param name="users">
        ///     Users to add.
        /// </param>
        private void addUsers(IList<UserProfile> users)
        {
            foreach (var user in users)
            {
                allUsers.Add(user);
            }
        }

        /// <summary>
        ///     Gets all users from all social networks.
        /// </summary>
        private void getAllUsers()
        {
            foreach (var network in SocialNetworks)
            {
                using (new StatusBusy(statusBarText, "Getting users from " + network.Name))
                {
                     addUsers(network.Users);
                }
            }
        }

        /// <summary>
        ///     Removes users from the collection of social
        ///     network users.
        /// </summary>
        /// <param name="users">
        ///     Users to remove.
        /// </param>
        private void removeUsers(IList<UserProfile> users)
        {
            foreach (var user in users)
            {
                allUsers.Remove(user);
            }
        }

        /// <summary>
        ///     Refreshes the list of users on the form.
        /// </summary>
        private void refreshUsers()
        {
            if (listBoxUsers != null)
            {
                listBoxUsers.ItemsSource = Users;
            }
        }

        /// <summary>
        ///     Opens a new dialog that connects to a twitter account.
        /// </summary>
        private void MenuItemTwitter_Click(object sender, RoutedEventArgs e)
        {
            using (new StatusBusy(statusBarText, "Getting authorization URL..."))
            {
                new TwitterAuth().ShowDialog();
            }
        }

        /// <summary>
        ///     Opens a new dialog that connects to a facebook account.
        /// </summary>
        private void MenuItemFacebook_Click(object sender, RoutedEventArgs e)
        {
            using (new StatusBusy(statusBarText, "Getting authorization URL..."))
            {
                new FacebookAuth().ShowDialog();
            }
        }

        /// <summary>
        ///     Sends the message to registered social networks.
        /// </summary>
        private void ButtonSend_Click(object sender, RoutedEventArgs e)
        {
            using (new StatusBusy(statusBarText, "Sending message..."))
            {
                var networks = getCheckedNetworks();
                var statuses = sendAllMessages(networks);
                showMessageStatuses(statuses);
            }
        }

        /// <summary>
        ///     Gets a collection of checked social networks.
        /// </summary>
        private IEnumerable<SocialNetwork> getCheckedNetworks()
        {
            foreach (var network in checkedListBoxSocialNetworks.SelectedItems)
            {
                yield return network as SocialNetwork;
            }
        }

        /// <summary>
        ///     Calls the SendMessage method for all checked
        ///     social networks.
        /// </summary>
        /// <returns>
        ///     One send status for each message.
        /// </returns>
        private IEnumerable<SendMessageStatus> sendAllMessages
            (IEnumerable<SocialNetwork> socialNetworks)
        {
            foreach (var socialNetwork in socialNetworks)
            {
                SendMessageStatus status = socialNetwork.SendMessage(this);
                yield return status;
            }
        }

        /// <summary>
        ///     Shows message statuses to the user.
        /// </summary>
        private void showMessageStatuses(IEnumerable<SendMessageStatus> statuses)
        {
            foreach (var status in statuses)
            {
                status.ShowStatusMessageBox();
            }
        }

        private void MenuItemExit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void txtMessageBody_TextChanged(object sender, TextChangedEventArgs e)
        {
            btnSend.IsEnabled = sendEnabled;
        }

        private void checkedListBoxSocialNetworks_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            btnSend.IsEnabled = sendEnabled;
        }

        /// <summary>
        ///     Refreshes the list of users so that it contains only
        ///     the users who have the string from the search textbox 
        ///     in their name.
        /// </summary>
        private void txtUsers_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (ignoreTextChanged)
            {
                return;
            }

            string currentText = txtUsers.Text;
            displaySearchUsersInTextbox = string.IsNullOrEmpty(currentText);

            if (string.IsNullOrEmpty(currentText))
            {
                Users = allUsers.MergeSort();
            }
            else
            {
                Users = allUsers.AsParallel()
                        .Where(u => u.Name.IndexOf(currentText, StringComparison.OrdinalIgnoreCase) >= 0)
                        .ToList()
                        .MergeSort();
            }

            refreshUsers();
        }

        private void txtUsers_GotFocus(object sender, RoutedEventArgs e)
        {
            if (displaySearchUsersInTextbox)
            {
                ignoreTextChanged = true;
                txtUsers.Text = string.Empty;
                txtUsers.FontStyle = FontStyles.Normal;
                txtUsers.Foreground = Brushes.Black;
                ignoreTextChanged = false;
            }
        }

        private void txtUsers_LostFocus(object sender, RoutedEventArgs e)
        {
            if (displaySearchUsersInTextbox)
            {
                ignoreTextChanged = true;
                txtUsers.Text = "Search users";
                txtUsers.FontStyle = FontStyles.Italic;
                txtUsers.Foreground = Brushes.Gray;
                ignoreTextChanged = false;
            }
        }

        private bool ignoreTextChanged;

        private void showUserDetails()
        {
            UserProfile user = listBoxUsers.SelectedItem as UserProfile;

            if (user != null)
            {
                user.GetUserDetailsWindow().Show();
            }
            else
            {
                MessageBox.Show("User details are unavailable!",
                    "Unavailable", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }

        private void listBoxUsers_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                showUserDetails();
            }
        }

        private void listBoxUsers_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            showUserDetails();
        }

        private void ContextMenuDetails_Click(object sender, EventArgs e)
        {
            showUserDetails();
        }

        private void imageRefreshUsers_MouseDown(object sender, MouseButtonEventArgs e)
        {
            allUsers.Clear();
            setLateBindings();
        }
    }
}
