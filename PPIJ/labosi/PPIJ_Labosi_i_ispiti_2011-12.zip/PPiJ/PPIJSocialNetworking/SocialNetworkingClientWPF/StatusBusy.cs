﻿using System;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Threading;

/// <summary>
///     Replaces the current cursor with WaitCursor and
///     displays a status text to a given ToolStripLabel.
/// </summary>
/// <remarks>
///     This class is intended for notyifing the user that
///     the main thread is doing some work and that the GUI
///     is not responding.
/// </remarks>
/// <example>
///     using(new StatusBusy(label, "Busy..."))
///     {
///         // do work
///     }
/// </example>
public class StatusBusy : IDisposable
{
    /// <summary>
    ///     Current cursor.
    /// </summary>
    public Cursor Cursor { get; private set; }

    /// <summary>
    ///     Label on which to display the message.
    /// </summary>
    public StatusBarItem Component { get; private set; }

    /// <summary>
    ///     Parent window of Component.
    /// </summary>
    public Window Owner { get; private set; }

    /// <summary>
    ///     Current label text.
    /// </summary>
    public string ComponentText { get; private set; }

    public StatusBusy(StatusBarItem component = null, string busyMessage = null)
    {
        Owner = Window.GetWindow(component);

        if (component != null)
        {
            Component = component;
            ComponentText = Component.Content != null
                ? Component.Content.ToString()
                : string.Empty;
            Component.Content = busyMessage;
            Component.Refresh();
        }

        Cursor = Owner.Cursor;
        Owner.Cursor = Cursors.Wait;
    }

    void IDisposable.Dispose()
    {
        if (Component != null)
        {
            Component.Content = ComponentText;
            Component.Refresh();
        }

        Owner.Cursor = Cursor;
    }
}

internal static class Helper
{
    private static Action EmptyDelegate = delegate() { };

    public static void Refresh(this UIElement uiElement)
    {
        uiElement.Dispatcher.Invoke(DispatcherPriority.Render, EmptyDelegate);
    }
}