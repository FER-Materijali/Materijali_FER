﻿using System.Windows;
using SocialNetworkLibrary;

namespace SocialNetworkingClientWPF
{
    /// <summary>
    /// Interaction logic for FacebookAuth.xaml
    /// </summary>
    public partial class FacebookAuth : Window
    {
        private bool authorizationOk = false;

        public FacebookAuth()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            webBrowser.Source = FacebookProvider.Instance.AuthorizationUri;
        }

        private void webBrowser_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {
            authorizationOk = FacebookProvider.Instance.AuthorizeUser(webBrowser.Source);

            if (authorizationOk)
            {
                Close();
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (authorizationOk)
            {
                MessageBox.Show("Authorization succeded.",
                        "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Authorization failed.",
                        "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
