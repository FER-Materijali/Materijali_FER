﻿using System;
using System.Windows.Forms;
using SocialNetworkLibrary;

namespace SocialNetworkingClient
{
    public partial class FacebookAuth : Form
    {
        private bool authorizationOk = false;

        public FacebookAuth()
        {
            InitializeComponent();
        }

        private void FacebookAuth_Load(object sender, EventArgs e)
        {
            webBrowser.Url = FacebookProvider.Instance.AuthorizationUri;
        }

        private void webBrowser_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            authorizationOk = FacebookProvider.Instance.AuthorizeUser(webBrowser.Url);

            if (authorizationOk)
            {
                Close();
            }
        }

        private void FacebookAuth_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (authorizationOk)
            {
                MessageBox.Show("Authorization succeded.",
                        "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Authorization failed.",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
