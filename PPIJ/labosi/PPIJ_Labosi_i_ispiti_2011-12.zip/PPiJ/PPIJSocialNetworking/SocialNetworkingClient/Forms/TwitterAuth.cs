﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows.Forms;
using SocialNetworkLibrary;

namespace SocialNetworkingClient
{
    public partial class TwitterAuth : Form
    {
        public TwitterAuth()
        {
            InitializeComponent();
        }

        private void TwitterPIN_Load(object sender, EventArgs e)
        {
            txtTwitterPIN.Focus();
        }

        private void TwitterPIN_Shown(object sender, EventArgs e)
        {
            // delegate a new background worker to open the authorization url
            BackgroundWorker worker = new BackgroundWorker();
            worker.DoWork += new DoWorkEventHandler(openAuthorizationURL);
            worker.RunWorkerAsync();
        }

        private void openAuthorizationURL(object sender, DoWorkEventArgs e)
        {
            using (new StatusBusy(toolStripStatusLabel, "Opening authorization URL..."))
            {
                string authorizationURI = TwitterProvider.Instance.AuthorizationURL;
                ProcessStartInfo sInfo = new ProcessStartInfo(authorizationURI);
                Process.Start(sInfo);
            }
        }

        private void submitPIN_Click(object sender, EventArgs e)
        {
            string pin = txtTwitterPIN.Text;
            bool authorizationOk;

            using (new StatusBusy(toolStripStatusLabel, "Authorizing..."))
            {
                authorizationOk = TwitterProvider.Instance.AuthorizeUser(pin);    
            }

            if (authorizationOk)
            {
                MessageBox.Show("Authorization succeded.", 
                    "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Wrong pin!", 
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Close();
        }

        private void txtPIN_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtTwitterPIN.Text))
            {
                errorProvider.SetError(txtTwitterPIN, "Enter twitter pin");
                e.Cancel = true;
            }
            else
            {
                e.Cancel = false;
            }
        }
    }
}
