﻿using PPIJServicesLibrary;

namespace SocialNetworkingClient
{
    partial class SocialNetworksManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnSend = new System.Windows.Forms.Button();
            this.txtMessageBody = new System.Windows.Forms.TextBox();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.connectToTwitterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItemExit = new System.Windows.Forms.ToolStripMenuItem();
            this.lblAuthor = new System.Windows.Forms.Label();
            this.txtAuthor = new System.Windows.Forms.TextBox();
            this.lblReply = new System.Windows.Forms.Label();
            this.txtReply = new System.Windows.Forms.TextBox();
            this.lblMessageBody = new System.Windows.Forms.Label();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabelStatusText = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.checkedListBoxSocialNetworks = new System.Windows.Forms.CheckedListBox();
            this.labelSocialNetworks = new System.Windows.Forms.Label();
            this.listBoxUsers = new System.Windows.Forms.ListBox();
            this.contextMenuUsers = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.detailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtUsers = new System.Windows.Forms.TextBox();
            this.lblUsers = new System.Windows.Forms.Label();
            this.connectToFacebookToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.socialNetworkBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.menuStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.contextMenuUsers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.socialNetworkBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSend
            // 
            this.btnSend.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSend.Enabled = false;
            this.btnSend.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnSend.Location = new System.Drawing.Point(442, 317);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(80, 35);
            this.btnSend.TabIndex = 0;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // txtMessageBody
            // 
            this.txtMessageBody.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMessageBody.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtMessageBody.Location = new System.Drawing.Point(188, 108);
            this.txtMessageBody.Multiline = true;
            this.txtMessageBody.Name = "txtMessageBody";
            this.txtMessageBody.Size = new System.Drawing.Size(334, 100);
            this.txtMessageBody.TabIndex = 1;
            this.txtMessageBody.TextChanged += new System.EventHandler(this.txtMessageBody_TextChanged);
            // 
            // menuStrip
            // 
            this.menuStrip.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.menuStrip.Size = new System.Drawing.Size(534, 24);
            this.menuStrip.TabIndex = 3;
            this.menuStrip.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.connectToTwitterToolStripMenuItem,
            this.connectToFacebookToolStripMenuItem,
            this.toolStripSeparator1,
            this.toolStripMenuItemExit});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.menuToolStripMenuItem.Text = "Menu";
            // 
            // connectToTwitterToolStripMenuItem
            // 
            this.connectToTwitterToolStripMenuItem.Name = "connectToTwitterToolStripMenuItem";
            this.connectToTwitterToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
            this.connectToTwitterToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.connectToTwitterToolStripMenuItem.Text = "Connect to &Twitter";
            this.connectToTwitterToolStripMenuItem.Click += new System.EventHandler(this.connectToTwitterToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(219, 6);
            // 
            // toolStripMenuItemExit
            // 
            this.toolStripMenuItemExit.Name = "toolStripMenuItemExit";
            this.toolStripMenuItemExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.toolStripMenuItemExit.Size = new System.Drawing.Size(222, 22);
            this.toolStripMenuItemExit.Text = "E&xit";
            this.toolStripMenuItemExit.Click += new System.EventHandler(this.toolStripMenuItemExit_Click);
            // 
            // lblAuthor
            // 
            this.lblAuthor.AutoSize = true;
            this.lblAuthor.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblAuthor.Location = new System.Drawing.Point(185, 37);
            this.lblAuthor.Name = "lblAuthor";
            this.lblAuthor.Size = new System.Drawing.Size(51, 18);
            this.lblAuthor.TabIndex = 5;
            this.lblAuthor.Text = "Author:";
            // 
            // txtAuthor
            // 
            this.txtAuthor.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAuthor.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtAuthor.Location = new System.Drawing.Point(263, 36);
            this.txtAuthor.Name = "txtAuthor";
            this.txtAuthor.Size = new System.Drawing.Size(259, 20);
            this.txtAuthor.TabIndex = 6;
            // 
            // lblReply
            // 
            this.lblReply.AutoSize = true;
            this.lblReply.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblReply.Location = new System.Drawing.Point(185, 63);
            this.lblReply.Name = "lblReply";
            this.lblReply.Size = new System.Drawing.Size(60, 18);
            this.lblReply.TabIndex = 7;
            this.lblReply.Text = "Reply to:";
            // 
            // txtReply
            // 
            this.txtReply.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtReply.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtReply.Location = new System.Drawing.Point(263, 62);
            this.txtReply.Name = "txtReply";
            this.txtReply.Size = new System.Drawing.Size(259, 20);
            this.txtReply.TabIndex = 8;
            // 
            // lblMessageBody
            // 
            this.lblMessageBody.AutoSize = true;
            this.lblMessageBody.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblMessageBody.Location = new System.Drawing.Point(185, 87);
            this.lblMessageBody.Name = "lblMessageBody";
            this.lblMessageBody.Size = new System.Drawing.Size(90, 18);
            this.lblMessageBody.TabIndex = 9;
            this.lblMessageBody.Text = "Message body:";
            // 
            // statusStrip
            // 
            this.statusStrip.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabelStatusText,
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 355);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(534, 22);
            this.statusStrip.TabIndex = 13;
            this.statusStrip.Text = "statusStrip1";
            // 
            // toolStripStatusLabelStatusText
            // 
            this.toolStripStatusLabelStatusText.Name = "toolStripStatusLabelStatusText";
            this.toolStripStatusLabelStatusText.Size = new System.Drawing.Size(47, 17);
            this.toolStripStatusLabelStatusText.Text = "Status: ";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(0, 17);
            // 
            // checkedListBoxSocialNetworks
            // 
            this.checkedListBoxSocialNetworks.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.checkedListBoxSocialNetworks.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.socialNetworkBindingSource, "Name", true));
            this.checkedListBoxSocialNetworks.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.checkedListBoxSocialNetworks.FormattingEnabled = true;
            this.checkedListBoxSocialNetworks.Location = new System.Drawing.Point(188, 232);
            this.checkedListBoxSocialNetworks.Name = "checkedListBoxSocialNetworks";
            this.checkedListBoxSocialNetworks.Size = new System.Drawing.Size(334, 79);
            this.checkedListBoxSocialNetworks.TabIndex = 14;
            this.checkedListBoxSocialNetworks.SelectedIndexChanged += new System.EventHandler(this.checkedListBoxSocialNetworks_SelectedIndexChanged);
            // 
            // labelSocialNetworks
            // 
            this.labelSocialNetworks.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelSocialNetworks.AutoSize = true;
            this.labelSocialNetworks.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelSocialNetworks.Location = new System.Drawing.Point(188, 211);
            this.labelSocialNetworks.Name = "labelSocialNetworks";
            this.labelSocialNetworks.Size = new System.Drawing.Size(102, 18);
            this.labelSocialNetworks.TabIndex = 15;
            this.labelSocialNetworks.Text = "Social networks:";
            // 
            // listBoxUsers
            // 
            this.listBoxUsers.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.listBoxUsers.ContextMenuStrip = this.contextMenuUsers;
            this.listBoxUsers.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.listBoxUsers.FormattingEnabled = true;
            this.listBoxUsers.ItemHeight = 16;
            this.listBoxUsers.Location = new System.Drawing.Point(13, 88);
            this.listBoxUsers.Name = "listBoxUsers";
            this.listBoxUsers.Size = new System.Drawing.Size(166, 260);
            this.listBoxUsers.TabIndex = 16;
            this.listBoxUsers.DoubleClick += new System.EventHandler(this.listBoxUsers_DoubleClick);
            this.listBoxUsers.KeyDown += new System.Windows.Forms.KeyEventHandler(this.listBoxUsers_KeyDown);
            // 
            // contextMenuUsers
            // 
            this.contextMenuUsers.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.detailsToolStripMenuItem});
            this.contextMenuUsers.Name = "contextMenuUsers";
            this.contextMenuUsers.Size = new System.Drawing.Size(110, 26);
            // 
            // detailsToolStripMenuItem
            // 
            this.detailsToolStripMenuItem.Name = "detailsToolStripMenuItem";
            this.detailsToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.detailsToolStripMenuItem.Text = "Details";
            this.detailsToolStripMenuItem.Click += new System.EventHandler(this.detailsToolStripMenuItem_Click);
            // 
            // txtUsers
            // 
            this.txtUsers.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtUsers.ForeColor = System.Drawing.Color.Gray;
            this.txtUsers.Location = new System.Drawing.Point(13, 61);
            this.txtUsers.Name = "txtUsers";
            this.txtUsers.Size = new System.Drawing.Size(166, 20);
            this.txtUsers.TabIndex = 17;
            this.txtUsers.Text = "Search users";
            this.txtUsers.TextChanged += new System.EventHandler(this.txtUsers_TextChanged);
            this.txtUsers.Enter += new System.EventHandler(this.txtUsers_Enter);
            this.txtUsers.Leave += new System.EventHandler(this.txtUsers_Leave);
            // 
            // lblUsers
            // 
            this.lblUsers.AutoSize = true;
            this.lblUsers.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblUsers.Location = new System.Drawing.Point(13, 36);
            this.lblUsers.Name = "lblUsers";
            this.lblUsers.Size = new System.Drawing.Size(47, 18);
            this.lblUsers.TabIndex = 18;
            this.lblUsers.Text = "Users:";
            // 
            // connectToFacebookToolStripMenuItem
            // 
            this.connectToFacebookToolStripMenuItem.Name = "connectToFacebookToolStripMenuItem";
            this.connectToFacebookToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
            this.connectToFacebookToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.connectToFacebookToolStripMenuItem.Text = "Connect to &Facebook";
            this.connectToFacebookToolStripMenuItem.Click += new System.EventHandler(this.connectToFacebookToolStripMenuItem_Click);
            // 
            // socialNetworkBindingSource
            // 
            this.socialNetworkBindingSource.DataSource = typeof(SocialNetworkLibrary.SocialNetwork);
            // 
            // SocialNetworksManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 377);
            this.Controls.Add(this.lblUsers);
            this.Controls.Add(this.txtUsers);
            this.Controls.Add(this.listBoxUsers);
            this.Controls.Add(this.labelSocialNetworks);
            this.Controls.Add(this.checkedListBoxSocialNetworks);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.lblMessageBody);
            this.Controls.Add(this.txtReply);
            this.Controls.Add(this.lblReply);
            this.Controls.Add(this.txtAuthor);
            this.Controls.Add(this.lblAuthor);
            this.Controls.Add(this.txtMessageBody);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.menuStrip);
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip;
            this.MinimumSize = new System.Drawing.Size(550, 415);
            this.Name = "SocialNetworksManager";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Social Networks Manager";
            this.Load += new System.EventHandler(this.SocialNetworksManager_Load);
            this.Shown += new System.EventHandler(this.SocialNetworksManager_Shown);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.contextMenuUsers.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.socialNetworkBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.TextBox txtMessageBody;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem connectToTwitterToolStripMenuItem;
        private System.Windows.Forms.Label lblAuthor;
        private System.Windows.Forms.TextBox txtAuthor;
        private System.Windows.Forms.Label lblReply;
        private System.Windows.Forms.TextBox txtReply;
        private System.Windows.Forms.Label lblMessageBody;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemExit;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelStatusText;
        private System.Windows.Forms.CheckedListBox checkedListBoxSocialNetworks;
        private System.Windows.Forms.Label labelSocialNetworks;
        private System.Windows.Forms.BindingSource socialNetworkBindingSource;
        private System.Windows.Forms.ListBox listBoxUsers;
        private System.Windows.Forms.TextBox txtUsers;
        private System.Windows.Forms.Label lblUsers;
        private System.Windows.Forms.ContextMenuStrip contextMenuUsers;
        private System.Windows.Forms.ToolStripMenuItem detailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem connectToFacebookToolStripMenuItem;
    }
}

