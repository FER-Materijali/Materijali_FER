﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using PPIJServicesLibrary;
using Sorters;
using SocialNetworkLibrary;

namespace SocialNetworkingClient
{
    /// <summary>
    ///     Main form.
    /// </summary>
    public partial class SocialNetworksManager : Form, IMessageForm
    {
        #region IMessageForm interface

        public string Author
        {
            get { return txtAuthor.Text; }
        }

        public string MessageBody
        {
            get { return txtMessageBody.Text; }
        }

        public string Reply
        {
            get { return txtReply.Text; }
        }

        /// <summary>
        ///     Registers a new social network to this form.
        /// </summary>
        public void RegisterNetwork(SocialNetwork network)
        {
            if (socialNetworks.Contains(network))
            {
                throw new Exception(network.Name +
                    " is already registered to this form.");
            }
            socialNetworks.Add(network);
        }

        #endregion

        /// <summary>
        ///     Collection of social networks registered to
        ///     this form.
        /// </summary>
        private IList<SocialNetwork> socialNetworks { get; set; }

        /// <summary>
        ///     Collection of users to display on the form.
        /// </summary>
        private IList<UserProfile> users { get; set; }

        /// <summary>
        ///     Collection of all users from all social networks.
        /// </summary>
        /// <remarks>
        ///     This collection is not automatically updated if the list
        ///     of users from a social network changes during the runtime 
        ///     of this application.
        /// </remarks>
        private IList<UserProfile> allUsers { get; set; }

        /// <summary>
        ///     True if the message can be send to a network.
        /// </summary>
        public bool sendEnabled
        {
            get
            {
                bool messageBodyHasText = !string.IsNullOrEmpty(txtMessageBody.Text);
                bool atLeastOneNetworkIsSelected = 
                    checkedListBoxSocialNetworks.CheckedItems.Count > 0;

                return messageBodyHasText && atLeastOneNetworkIsSelected;
            }
        }

        /// <summary>
        ///     If true, displays the string 'Search users' in the 
        ///     search text box.
        /// </summary>
        private bool displaySearchUsersInTextbox = true;

        public SocialNetworksManager()
        {
            InitializeComponent();
            socialNetworks = new List<SocialNetwork>();
            allUsers = new List<UserProfile>();
            users = new List<UserProfile>();
        }

        private void SocialNetworksManager_Load(object sender, EventArgs e)
        {
            setBindings();
        }

        private void SocialNetworksManager_Shown(object sender, EventArgs e)
        {
            setLateBindings();
        }

        /// <summary>
        ///     Binds the socialNetworks collection to the 
        ///     checkedListBoxSocialNetworks component.
        /// </summary>
        private void setBindings()
        {
            checkedListBoxSocialNetworks.DataSource = socialNetworks;
            checkedListBoxSocialNetworks.DisplayMember = "Name";
        }

        /// <summary>
        ///     Binds the users listbox to all users from all registered
        ///     social networks.
        /// </summary>
        /// <remarks>
        ///     Getting all users can be expensive.
        /// </remarks>
        private void setLateBindings()
        {
            getAllUsers();
            listBoxUsers.DataSource = allUsers.MergeSort();
            listBoxUsers.DisplayMember = "Name";
        }

        /// <summary>
        ///     Adds users to the collection of social
        ///     network users.
        /// </summary>
        /// <param name="users">
        ///     Users to add.
        /// </param>
        private void addUsers(IEnumerable<UserProfile> users)
        {
            foreach (var user in users)
            {
                allUsers.Add(user);
            }
        }

        /// <summary>
        ///     Gets all users from all social networks.
        /// </summary>
        private void getAllUsers()
        {
            foreach (var network in socialNetworks)
            {
                using (new StatusBusy(toolStripStatusLabel, "Getting users from " + network.Name))
                {
                    Parallel.Invoke(() => addUsers(network.Users));
                }
            }
        }

        /// <summary>
        ///     Removes users from the collection of social
        ///     network users.
        /// </summary>
        /// <param name="users">
        ///     Users to remove.
        /// </param>
        private void removeUsers(IEnumerable<UserProfile> users)
        {
            foreach (var user in users)
            {
                allUsers.Remove(user);
            }
        }

        /// <summary>
        ///     Refreshes the list of users on the form.
        /// </summary>
        private void refreshUsers()
        {
            listBoxUsers.DataSource = users;
        }

        /// <summary>
        ///     Opens a new dialog that connects to a twitter account.
        /// </summary>
        private void connectToTwitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (new StatusBusy(toolStripStatusLabel, "Getting authorization URL..."))
            {
                new TwitterAuth().ShowDialog();
            }
        }

        /// <summary>
        ///     Opens a new dialog that connects to a facebook account.
        /// </summary>
        private void connectToFacebookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (new StatusBusy(toolStripStatusLabel, "Getting authorization URL..."))
            {
                new FacebookAuth().ShowDialog();
            }
        }

        /// <summary>
        ///     Sends the message to registered social networks.
        /// </summary>
        private void btnSend_Click(object sender, EventArgs e)
        {
            using (new StatusBusy(toolStripStatusLabel, "Sending message..."))
            {
                var networks = getCheckedNetworks();
                var statuses = sendAllMessages(networks);
                showMessageStatuses(statuses);
            }
        }

        /// <summary>
        ///     Gets a collection of checked social networks.
        /// </summary>
        private IEnumerable<SocialNetwork> getCheckedNetworks()
        {
            foreach (var network in checkedListBoxSocialNetworks.CheckedItems)
            {
                yield return network as SocialNetwork;
            }
        }

        /// <summary>
        ///     Calls the SendMessage method for all checked
        ///     social networks.
        /// </summary>
        /// <returns>
        ///     One send status for each message.
        /// </returns>
        private IEnumerable<SendMessageStatus> sendAllMessages
            (IEnumerable<SocialNetwork> socialNetworks)
        {
            foreach (var socialNetwork in socialNetworks)
            {
                SendMessageStatus status = socialNetwork.SendMessage(this);
                yield return status;
            }
        }
        
        /// <summary>
        ///     Shows message statuses to the user.
        /// </summary>
        private void showMessageStatuses(IEnumerable<SendMessageStatus> statuses)
        {
            foreach (var status in statuses)
            {
                status.ShowStatusMessageBox();
            }
        }

        private void toolStripMenuItemExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtMessageBody_TextChanged(object sender, EventArgs e)
        {
            btnSend.Enabled = sendEnabled;
        }

        private void checkedListBoxSocialNetworks_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnSend.Enabled = sendEnabled;
        }

        /// <summary>
        ///     Refreshes the list of users so that it contains only
        ///     the users which have the string from the search textbox 
        ///     in their name.
        /// </summary>
        private void txtUsers_TextChanged(object sender, EventArgs e)
        {
            if (ignoreTextChanged)
            {
                return;
            }

            string currentText = txtUsers.Text;
            displaySearchUsersInTextbox = string.IsNullOrEmpty(currentText);

            if (string.IsNullOrEmpty(currentText))
            {
                users = allUsers.MergeSort();
            }
            else
            {
                users = allUsers.AsParallel()
                        .Where(u => u.Name.IndexOf(currentText, StringComparison.OrdinalIgnoreCase) >= 0)
                        .ToList()
                        .MergeSort();
            }

            refreshUsers();
        }

        private void txtUsers_Enter(object sender, EventArgs e)
        {
            if (displaySearchUsersInTextbox)
            {
                ignoreTextChanged = true;
                txtUsers.Text = string.Empty;
                txtUsers.Font = new Font(new FontFamily("Trebuchet MS"), 8, FontStyle.Regular);
                txtUsers.ForeColor = Color.Black;
                ignoreTextChanged = false;
            }
        }

        private void txtUsers_Leave(object sender, EventArgs e)
        {
            if (displaySearchUsersInTextbox)
            {
                ignoreTextChanged = true;
                txtUsers.Text = "Search users";
                txtUsers.Font = new Font(new FontFamily("Trebuchet MS"), 8, FontStyle.Italic);
                txtUsers.ForeColor = Color.Gray;
                ignoreTextChanged = false;
            }
        }

        private bool ignoreTextChanged;

        private void showUserDetails()
        {
            UserProfile user = listBoxUsers.SelectedItem as UserProfile;

            if (user != null)
            {
                user.GetUserDetailsForm().Show();
            }
            else
            {
                MessageBox.Show("User details are unavailable!", 
                    "Unavailable", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void listBoxUsers_DoubleClick(object sender, EventArgs e)
        {
            showUserDetails();
        }

        private void listBoxUsers_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                showUserDetails();
            }
        }

        private void detailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showUserDetails();
        }
    }
}
