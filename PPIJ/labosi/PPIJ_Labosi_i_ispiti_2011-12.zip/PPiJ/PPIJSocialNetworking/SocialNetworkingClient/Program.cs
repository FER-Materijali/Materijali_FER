﻿using System;
using System.Windows.Forms;
using SocialNetworkLibrary;
using MI;

namespace SocialNetworkingClient
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // create twitter, PPiJBoard and Facebook social networks
            SocialNetworksManager socialNetwork = new SocialNetworksManager();
            new Twitter(socialNetwork);
            new PPiJBoard(socialNetwork);
            new Facebook(socialNetwork);

            string putanja = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            Postavke.PutanjaDnevnika = new LokalnaPutanja(putanja);

            Application.Run(socialNetwork);
        }
    }
}
