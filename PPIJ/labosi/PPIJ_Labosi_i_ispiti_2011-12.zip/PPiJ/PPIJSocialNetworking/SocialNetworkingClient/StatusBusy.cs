﻿using System;
using System.Windows.Forms;

/// <summary>
///     Replaces the current cursor with WaitCursor and
///     displays a status text to a given ToolStripLabel.
/// </summary>
/// <remarks>
///     This class is intended for notyifing the user that
///     the main thread is doing some work and that the GUI
///     is not responding.
/// </remarks>
/// <example>
///     using(new StatusBusy(label, "Busy..."))
///     {
///         // do work
///     }
/// </example>
public class StatusBusy : IDisposable
{
    /// <summary>
    ///     Current cursor.
    /// </summary>
    public Cursor Cursor { get; private set; }

    /// <summary>
    ///     Label on which to display the message.
    /// </summary>
    public ToolStripLabel Component { get; private set; }

    /// <summary>
    ///     Current label text.
    /// </summary>
    public string ComponentText { get; private set; }

    public StatusBusy(ToolStripLabel component = null, string busyMessage = null)
    {
        if (component != null)
        {
            Component = component;
            ComponentText = component.Text;
            component.Text = busyMessage;
            component.GetCurrentParent().Refresh();
        }

        Cursor = Cursor.Current;
        Cursor.Current = Cursors.WaitCursor;
    }

    void IDisposable.Dispose()
    {
        if (Component != null)
        {
            Component.Text = ComponentText;
            Component.GetCurrentParent().Refresh();
        }
        
        Cursor.Current = Cursor;
    }
}