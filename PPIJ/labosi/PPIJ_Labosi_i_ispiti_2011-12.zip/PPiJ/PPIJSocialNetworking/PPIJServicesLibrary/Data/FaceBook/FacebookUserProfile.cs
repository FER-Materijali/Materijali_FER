﻿using System;
using System.Windows;
using System.Windows.Forms;

namespace PPIJServicesLibrary
{
    public class FacebookUserProfile : UserProfile
    {
        public string Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserName { get; set; }
        public string Link { get; set; }
        public string Gender { get; set; }
        public string Locale { get; set; }
        public DateTime UpdateTime { get; set; }
        public string ImageUri { get; set; }

        public override Form GetUserDetailsForm()
        {
            return new FacebookUserDetailsForm() { User = this };
        }

        public override Window GetUserDetailsWindow()
        {
            return new FacebookUserDetailsWindow() { User = this };
        }
    }
}
