﻿using System;
using System.Windows;
using System.Windows.Media.Imaging;

namespace PPIJServicesLibrary
{
    /// <summary>
    /// Interaction logic for FacebookUserDetailsWindow.xaml
    /// </summary>
    public partial class FacebookUserDetailsWindow : Window
    {
        public FacebookUserProfile User { get; set; }

        public FacebookUserDetailsWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.Title += User.Name;
            image.Source = new BitmapImage(new Uri(User.ImageUri));
            labelName.Content = User.Name;
            labelUserName.Content = User.UserName;
            hyperlinkUser.NavigateUri = new Uri(User.Link);
            hyperlinkUser.Inlines.Clear();
            hyperlinkUser.Inlines.Add(User.Link);
            textBoxGender.Text = User.Gender;
            textBoxLocale.Text = User.Locale;
            textBoxUpdateTime.Text = User.UpdateTime.ToString();
        }
    }
}
