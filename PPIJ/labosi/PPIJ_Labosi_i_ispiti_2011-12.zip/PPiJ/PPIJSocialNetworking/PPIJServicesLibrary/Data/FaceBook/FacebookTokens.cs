﻿namespace PPIJServicesLibrary
{
    public class FacebookTokens
    {
        private string accessToken;
        public string AccessToken
        {
            get { return accessToken; }
            set { accessToken = value; }
        }

        private string secretKey;
        public string SecretKey
        {
            get { return secretKey; }
            set { secretKey = value; }
        }

        private string apiKey;
        public string APIKey
        {
            get { return apiKey; }
            set { apiKey = value; }
        }
    }
}
