﻿using System;
using System.Windows.Forms;

namespace PPIJServicesLibrary
{
    public partial class FacebookUserDetailsForm : Form
    {
        public FacebookUserProfile User { get; set; }

        public FacebookUserDetailsForm()
        {
            InitializeComponent();
        }

        private void FacebookUserDetailsForm_Load(object sender, EventArgs e)
        {
            this.Text += User.Name;
            pictureBox.ImageLocation = User.ImageUri;
            labelName.Text = User.Name;
            labelUserName.Text = User.UserName;
            linkLabel.Text = User.Link;
            textBoxGender.Text = User.Gender;
            textBoxLocale.Text = User.Locale;
            textBoxUpdateTime.Text = User.UpdateTime.ToString();
        }
    }
}
