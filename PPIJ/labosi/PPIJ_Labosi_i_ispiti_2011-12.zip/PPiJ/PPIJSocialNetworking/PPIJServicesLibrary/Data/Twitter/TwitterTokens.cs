﻿namespace PPIJServicesLibrary
{
    public class TwitterTokens
    {
        private string accessToken;

        public string AccessToken
        {
            get { return accessToken; }
            set { accessToken = value; }
        }
        private string accessTokenSecret;

        public string AccessTokenSecret
        {
            get { return accessTokenSecret; }
            set { accessTokenSecret = value; }
        }
        private string consumerSecret;

        public string ConsumerSecret
        {
            get { return consumerSecret; }
            set { consumerSecret = value; }
        }
        private string consumerKey;

        public string ConsumerKey
        {
            get { return consumerKey; }
            set { consumerKey = value; }
        }
    }
}
