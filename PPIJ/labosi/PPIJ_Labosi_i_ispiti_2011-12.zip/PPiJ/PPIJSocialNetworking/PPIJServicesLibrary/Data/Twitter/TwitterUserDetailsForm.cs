﻿using System;
using System.Windows.Forms;

namespace PPIJServicesLibrary
{
    public partial class TwitterUserDetailsForm : Form
    {
        public TwitterUserProfile User { get; set; }

        public TwitterUserDetailsForm()
        {
            InitializeComponent();
        }

        private void TwitterUserDetailsForm_Load(object sender, EventArgs e)
        {
            this.Text += User.Name;
            pictureBox.ImageLocation = User.ProfileImageLocation;
            lblName.Text = User.Name;
            lblScreenName.Text = "@" + User.ScreenName;
            txtFollowers.Text = User.NumberOfFriends.ToString();
            txtTweets.Text = User.NumberOfStatuses.ToString();
            txtWebsite.Text = User.Website;
            txtStatus.Text = User.Status;
            txtLocation.Text = User.Location;
            txtLanguage.Text = User.Language;
            txtDescription.Text = User.Description;
        }
    }
}
