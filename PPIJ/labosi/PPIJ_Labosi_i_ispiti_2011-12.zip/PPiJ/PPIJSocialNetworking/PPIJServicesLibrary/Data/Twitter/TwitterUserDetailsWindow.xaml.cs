﻿using System;
using System.Windows;
using System.Windows.Media.Imaging;

namespace PPIJServicesLibrary
{
    /// <summary>
    /// Interaction logic for TwitterUserDetailsWindow.xaml
    /// </summary>
    public partial class TwitterUserDetailsWindow : Window
    {
        public TwitterUserProfile User { get; set; }

        public TwitterUserDetailsWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.Title += User.Name;
            pictureBox.Source = new BitmapImage(new Uri(User.ProfileImageLocation, UriKind.Absolute));
            lblName.Content = User.Name;
            lblScreenName.Content = "@" + User.ScreenName;
            txtFollowers.Text = User.NumberOfFriends.ToString();
            txtTweets.Text = User.NumberOfStatuses.ToString();
            txtWebsite.Text = User.Website;
            txtStatus.Text = User.Status;
            txtLocation.Text = User.Location;
            txtLanguage.Text = User.Language;
            txtDescription.Text = User.Description;
        }
    }
}
