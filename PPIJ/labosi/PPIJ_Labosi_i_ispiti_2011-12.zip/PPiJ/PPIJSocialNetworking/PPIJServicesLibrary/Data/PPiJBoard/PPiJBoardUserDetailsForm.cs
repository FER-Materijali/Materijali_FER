﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace PPIJServicesLibrary
{
    public partial class PPiJBoardUserDetailsForm : Form
    {
        public PPiJBoardUserProfile User { get; set; }

        public PPiJBoardUserDetailsForm()
        {
            InitializeComponent();
        }

        private void PPiJBoardUserDetailsForm_Load(object sender, EventArgs e)
        {
            this.Text += User.Name;
            lblName.Text = User.Name;
            textBoxMessages.Text = string.Join(Environment.NewLine + Environment.NewLine,
                User.Messages.Select(m =>
                    m.Text + Environment.NewLine +
                    string.Format("Id: {0} | Date posted: {1} | Reply to: {2}", m.Id, m.Posted, m.ReplyTo)
                )
            );
        }
    }
}
