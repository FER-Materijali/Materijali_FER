﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Forms;
using PPIJServicesLibrary.PPIJBoard;

namespace PPIJServicesLibrary
{
    public class PPiJBoardUserProfile : UserProfile
    {
        public IList<PPIJboardMessage> Messages { get; set; }

        public override Form GetUserDetailsForm()
        {
            return new PPiJBoardUserDetailsForm() { User = this };
        }

        public override Window GetUserDetailsWindow()
        {
            return new PPiJBoardUserDetailsWindow() { User = this };
        }
    }
}
