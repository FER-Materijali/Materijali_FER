﻿using System.Windows;
using System;
using System.Linq;

namespace PPIJServicesLibrary
{
    /// <summary>
    /// Interaction logic for PPiJBoardUserDetailsWindow.xaml
    /// </summary>
    public partial class PPiJBoardUserDetailsWindow : Window
    {
        public PPiJBoardUserProfile User { get; set; }

        public PPiJBoardUserDetailsWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.Title += User.Name;
            lblName.Content = User.Name;
            txtMessages.Text = string.Join(Environment.NewLine + Environment.NewLine,
                User.Messages.Select(m =>
                    m.Text + Environment.NewLine +
                    string.Format("Id: {0} | Date posted: {1} | Reply to: {2}", m.Id, m.Posted, m.ReplyTo)
                )
            );
        }
    }
}
