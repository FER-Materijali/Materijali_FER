﻿using System;
using System.Windows;
using System.Windows.Forms;

namespace PPIJServicesLibrary
{
    public abstract class UserProfile : IComparable<UserProfile>
    {
        protected string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        /// <summary>
        ///     Returns a windows form with user details.
        /// </summary>
        public abstract Form GetUserDetailsForm();

        /// <summary>
        ///     Returns a wpf window with user details.
        /// </summary>
        public abstract Window GetUserDetailsWindow(); 

        public override bool Equals(object obj)
        {
            UserProfile user = obj as UserProfile;

            if (user == null)
            {
                return false;
            }

            return user.Name == Name;
        }

        public override int GetHashCode()
        {
            return Name.GetHashCode();
        }

        public override string ToString()
        {
            return Name;
        }

        public int CompareTo(UserProfile other)
        {
            return Name.CompareTo(other.Name);
        }
    }
}
