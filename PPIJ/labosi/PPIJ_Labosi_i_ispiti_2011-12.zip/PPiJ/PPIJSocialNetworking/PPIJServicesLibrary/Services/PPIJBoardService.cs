﻿using System.Collections.Generic;
using System.Linq;
using PPIJServicesLibrary.PPIJBoard;

namespace PPIJServicesLibrary
{
    /// <summary>
    /// Statična servisna klasa za komunikaciju sa PPIJBoardom - služi kao lagani omotač (wrapper) oko klijenta prikladnog web servisa
    /// </summary>
    public static class PPIJBoardService
    {   
        /// <summary>
        /// Generira pristupni token za aplikaciju. Ukoliko aplikacija nije pronađena, baca AppNotFoundException, a ukoliko već postoji aktivni token ActiveTokenException.
        /// </summary>
        /// <param name="ApplicationKey">Aplikacijski ključ korisnikove aplikacije</param>
        /// <returns>Pristupni token</returns>
        public static string GetAccessToken(string ApplicationKey)
        {
            PPIJboardServiceSoapClient client = new PPIJboardServiceSoapClient();
            return client.GetAccessToken(ApplicationKey);
        }

        /// <summary>
        /// Dohvaća zadnjih nekoliko poruka na PPIJboardu u prikladnom formatu. Ukoliko je token istekao ili krivi, baca TokenNotValidException.
        /// </summary>
        /// <param name="token">Pristupni token</param>
        /// <param name="count">Broj poruka za dohvatiti</param>
        /// <returns>Poruke sa PPIJboarda</returns>
        public static List<PPIJboardMessage> GetLastMessages(string token, int count)
        {
            PPIJboardServiceSoapClient client = new PPIJboardServiceSoapClient();
            return client.GetLastMessages(token, count);
        }

        /// <summary>
        /// Dohvaća poruke na PPIJboardu u prikladnom formatu. Ukoliko je token istekao ili krivi, baca TokenNotValidException.
        /// </summary>
        /// <param name="token">Pristupni token</param>
        /// <returns>Poruke sa PPIJboarda</returns>
        public static List<PPIJboardMessage> GetMessages(string token)
        {
            PPIJboardServiceSoapClient client = new PPIJboardServiceSoapClient();
            return client.GetMessages(token);
        }

        /// <summary>
        /// Stavlja novu poruku na PPIJboard. Ukoliko je token istekao ili krivi, baca TokenNotValidException, a ukoliko su podaci krivi baca DataNotValidException.
        /// </summary>
        /// <param name="token">Pristupni token</param>
        /// <param name="author">Autor poruke</param>
        /// <param name="message">Sadržaj poruke</param>
        public static void PostMessage(string token, string author, string message)
        {
            PPIJboardServiceSoapClient client = new PPIJboardServiceSoapClient();
            client.PostMessage(token, author, message);
        }

        /// <summary>
        /// Stavlja novi odgovor na poruke na PPIJboard. Ukoliko je token istekao ili krivi, baca TokenNotValidException, a ukoliko su podaci krivi baca DataNotValidException.
        /// </summary>
        /// <param name="token">Pristupni token</param>
        /// <param name="author">Autor poruke</param>
        /// <param name="message">Sadržaj poruke</param>
        /// <param name="replyTo">ID poruke na koju se odgovara</param>
        public static void PostReply(string token, string author, string message, int? replyTo)
        {
            PPIJboardServiceSoapClient client = new PPIJboardServiceSoapClient();
            client.PostReply(token, author, message, replyTo);
        }

        /// <summary>
        /// Dohvaća listu korisnika servisa PPiJBoard.
        /// </summary>
        /// <param name="token">Pristupni token</param>
        /// <returns>Lista korisnika</returns>
        public static List<PPiJBoardUserProfile> GetUsers(string token)
        {
            List<PPiJBoardUserProfile> users = new List<PPiJBoardUserProfile>();

            var partialUsers = GetLastMessages(token, MAX_NUM_OF_MESSAGES);
            users = extractPPiJBoardUsers(partialUsers);

            return users;
        }

        private static List<PPiJBoardUserProfile> extractPPiJBoardUsers(List<PPIJboardMessage> partialUsers)
        {
            return (from pu in partialUsers
                    group pu by pu.Author into u
                    where !string.IsNullOrWhiteSpace(u.Key)
                    select new PPiJBoardUserProfile()
                    {
                        Name = u.Key,
                        Messages = u.OrderByDescending(m => m.Posted).ToList()
                    })
                    .ToList();
        }

        private const int MAX_NUM_OF_MESSAGES = 100;
    }
}
