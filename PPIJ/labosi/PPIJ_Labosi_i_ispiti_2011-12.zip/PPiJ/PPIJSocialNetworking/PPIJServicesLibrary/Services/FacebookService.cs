﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Facebook;
using Newtonsoft.Json.Linq;

namespace PPIJServicesLibrary
{
    public static class FacebookService
    {
        /// <summary>
        /// Generira URI za autorizaciju.
        /// </summary>
        /// <param name="APIKey"></param>
        /// <param name="scope"></param>
        /// <returns>URI za autorizaciju - prikazati korisniku</returns>
        public static string GetAuthorizationUri(string APIKey, string scope)
        {
            return string.Format("https://www.facebook.com/dialog/oauth?client_id={0}&scope={1}&redirect_uri=http://www.facebook.com/connect/login_success.html&response_type=token",
                APIKey, scope);
        }


        /// <summary>
        /// Dohvaća access token iz url-a dobivenog nakon autorizacije.
        /// </summary>
        /// <param name="responseUri">Url dobiven nakon autorizacije</param>
        /// <returns>access tokens</returns>
        public static string GetAccessToken(Uri responseUri)
        {
            FacebookClient fb = new FacebookClient();
            FacebookOAuthResult oauthResult;

            if (fb.TryParseOAuthCallbackUrl(responseUri, out oauthResult))
            {
                // The url is the result of OAuth 2.0 authentication
                if (oauthResult.IsSuccess)
                {
                    return oauthResult.AccessToken;
                }
            }

            throw new Exception("Url doesn't contain the access token.");
        }

        /// <summary>
        /// Postavlja novi post online.
        /// </summary>
        /// <param name="Tokens">Access token koji dopušta postavljanje posta na stranice korisnika</param>
        /// <param name="Message">Sadržaj posta - moguće korsistiti hash-tagove i sl. mogućnosti</param>
        /// <returns>Potvrda da li je postavljanje uspjelo</returns>
        public static bool Post(FacebookTokens Tokens, string Message)
        {
            try
            {
                FacebookClient client = new FacebookClient(Tokens.AccessToken);
                client.Post("PPIJ2012/feed", new { message = Message });
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Dohvaća pratitelje trenutnog korisnika.
        /// </summary>
        /// <param name="AccessToken">
        /// Facebook tokeni povezani sa računom trenutnog korisnika
        /// </param>
        /// <returns>Lista profila pratitelja trenutnog korisnika</returns>
        public static List<FacebookUserProfile> GetFriends(FacebookTokens tokens)
        {
            List<FacebookUserProfile> users = new List<FacebookUserProfile>();
            object friends = null;

            try
            {
                FacebookClient client = new FacebookClient(tokens.AccessToken);
                friends = client.Get("/me/friends");

                JObject jsonFriends = JObject.Parse(friends.ToString());
                Parallel.ForEach(jsonFriends["data"].Children(), friend =>
                {
                    FacebookUserProfile user = GetUserDetails(tokens.AccessToken, friend["id"].ToString());
                    if (user != null)
                    {
                        users.Add(user);
                    }
                });
            }
            catch (Exception)
            { }

            return users;
        }

        /// <summary>
        /// Dovaća detalje korisnika.
        /// </summary>
        /// <param name="accessToken">Access token za pristup podacima korisnika</param>
        /// <param name="userId">Id korisnika</param>
        /// <returns>Detalji facebook korisnika</returns>
        public static FacebookUserProfile GetUserDetails(string accessToken, string userId)
        {
            try
            {
                FacebookClient client = new FacebookClient(accessToken);
                JObject jsonFriend = JObject.Parse(client.Get("/" + userId).ToString());
                return new FacebookUserProfile()
                        {
                            Name = jsonFriend["name"].ToString(),
                            Id = jsonFriend["id"].ToString(),
                            FirstName = jsonFriend["first_name"].ToString(),
                            LastName = jsonFriend["last_name"].ToString(),
                            UserName = jsonFriend["username"].ToString(),
                            Link = jsonFriend["link"].ToString(),
                            Gender = jsonFriend["gender"].ToString(),
                            Locale = jsonFriend["locale"].ToString(),
                            UpdateTime = DateTime.Parse(jsonFriend["updated_time"].ToString()),
                            ImageUri = string.Format("https://graph.facebook.com/{0}/picture?type=large&access_token={1}",
                                jsonFriend["id"].ToString(), accessToken)
                        };
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
