﻿using System;
using System.Collections.Generic;
using System.Linq;
using PPIJ2012ZI;

namespace ZI
{
    public static class Program
    {
        public static void Main()
        {
            Console.WriteLine("Zadatak 1");
            DataValidation.ValidateDataFromSources();
            Console.WriteLine();

            IEnumerable<IContact> contacts = DataValidation.RemoveInvalidContacts(
                PPIJContacts.Instance.GetContacts());

            Console.WriteLine("Zadatak 2a");
            var namesCount = contacts.NamesCount();
            foreach (var name in namesCount.Take(20))
            {
                Console.WriteLine("Ime: {0} \t Count: {1}", name.Key, name.Value);
            }
            Console.WriteLine();

            Console.WriteLine("Zadatak 2b");
            var contactsWithSlavicNames = contacts.ContactsWithSlavicNames();
            foreach (var contact in contactsWithSlavicNames.Take(20))
            {
                Console.WriteLine("Ime: {0}", contact.FullName);
            }
            Console.WriteLine();

            Console.WriteLine("Zadatak 2c");
            var slavicNamesCount = contacts.SlavicNamesCount();
            foreach (var name in slavicNamesCount.Take(20))
            {
                Console.WriteLine("Ime: {0} \t Count: {1}", name.Key, name.Value);
            }
            Console.WriteLine();
        }
    }
}
