﻿using System.Collections.Generic;
using System.Linq;
using PPIJ2012ZI;

namespace ZI
{
    public static class DataQueryExtensions
    {
        public static Dictionary<string, int> NamesCount(this IEnumerable<IContact> contacts)
        {
            var namesCount = (from contact in contacts
                              group contact by contact.Name into contactGroup
                              select new
                              {
                                  Ime = contactGroup.Key,
                                  Count = contactGroup.Count()
                              })
                              .ToDictionary(cGroup => cGroup.Ime, cGroup => cGroup.Count);
            return namesCount;
        }

        public static IEnumerable<IContact> ContactsWithSlavicNames(this IEnumerable<IContact> contacts)
        {
            return from contact in contacts
                   where PPIJContacts.Instance.GetNameDefinitions().Contains(
                       new NameDefinition
                       {
                           Name = contact.Name,
                           Gender = contact.Gender,
                           Origin = "Slavensko"
                       })
                   select contact;

        }

        public static Dictionary<string, int> SlavicNamesCount(this IEnumerable<IContact> contacts)
        {
            return contacts.ContactsWithSlavicNames().NamesCount();
        }
    }
}
