﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using System.IO;

namespace PPIJ2012ZI
{
    /// <summary>
    /// Enumeracija za spol
    /// </summary>
    public enum Gender
    {
        Male, Female, Unknown
    }

    /// <summary>
    /// Definicija imena - sadrži ime, za imenovanje djece kojeg spola se tradicionalno koristi
    /// te izvor/porijetlo imena
    /// </summary>
    public struct NameDefinition
    {
        public string Name { get; set; }
        public Gender Gender { get; set; }
        public string Origin { get; set; }
    }

    /// <summary>
    /// Sučelje za definiranje sadržaja kontakta
    /// </summary>
    public interface IContact
    {
        string FullName { get; }
        string Name { get; }
        string Surname { get; }
        Gender Gender { get; }
    }

    
    /// <summary>
    /// Sučelje izvora kontakata - omogućava polimorfni dohvat kolekcija kontakata pojedinih izvora
    /// </summary>
    public interface IContactProvider
    {
        IEnumerable<IContact> GetContacts();
    }

    /// <summary>
    /// Reprezentativni random izvor kontakata
    /// </summary>
    public class PPIJContacts : IContactProvider
    {
        const string NAME_FILE_PATH = @"CroatianNameDefs.json";
        const string SURNAME_FILE_PATH = @"CroatianSurnameDefs.json";

        List<IContact> contacts;
        List<NameDefinition> nameDefs;
        List<string> surnames;

        private static PPIJContacts instance;
        public static PPIJContacts Instance
        {
            get
            {
                if (instance == null) instance = new PPIJContacts();
                return instance;
            }
        }
    
        
        public IEnumerable<IContact> GetContacts()
        {
            return contacts.AsReadOnly();
        }

        public IEnumerable<NameDefinition> GetNameDefinitions()
        {
            return nameDefs.AsReadOnly();
        }

        private PPIJContacts()
        {
            nameDefs = JsonConvert.DeserializeObject<List<NameDefinition>>(File.ReadAllText(NAME_FILE_PATH));
            surnames = JsonConvert.DeserializeObject<List<string>>(File.ReadAllText(SURNAME_FILE_PATH));

            contacts = new List<IContact>();
            Random randomizer = new Random((int)DateTime.Now.Ticks);
            for (int i = 0; i < 10000; i++)
            {
                int selectedNameId = randomizer.Next(nameDefs.Count);
                int selectedSurnameId = randomizer.Next(surnames.Count);
                string newContactName;
                string newContactSurname;
                if (randomizer.Next(100) > 10) newContactName = nameDefs[selectedNameId].Name;
                else newContactName = "";
                if (randomizer.Next(100) > 10) newContactSurname = surnames[selectedSurnameId];
                else newContactSurname = "";
                contacts.Add(new PPIJContact(newContactName, newContactSurname, nameDefs[selectedNameId].Gender));
            }
        }
    }

    /// <summary>
    /// Implementacija IContact sučelja za reprezentativne kontakte
    /// </summary>
    public class PPIJContact : IContact
    {
        private string name;
        private string surname;
        private Gender gender;

        public string FullName
        {
            get
            {
                string fullname = "";
                if (name != null) fullname += name;
                fullname += " ";
                if (surname != null) fullname += surname;
                return fullname;
            }
        }

        public string Name
        {
            get { return name; }
        }

        public string Surname
        {
            get { return surname; }
        }

        public Gender Gender
        {
            get { return gender; }
        }

        public PPIJContact(string name, string surname, Gender gender)
        {
            this.name = name;
            this.surname = surname;
            this.gender = gender;
        }
    }
}
