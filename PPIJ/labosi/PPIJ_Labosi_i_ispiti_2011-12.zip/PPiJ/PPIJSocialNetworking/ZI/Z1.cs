﻿using System;
using System.Collections.Generic;
using System.Linq;
using PPIJ2012ZI;

namespace ZI
{
    public static class DataValidation
    {
        public static IEnumerable<T> RemoveInvalidContacts<T>(IEnumerable<T> contacts)
            where T : IContact
        {
            foreach (var contact in contacts)
            {
                bool nameIsEmpty = string.IsNullOrEmpty(contact.Name);
                bool surnameIsEmpty = string.IsNullOrEmpty(contact.Surname);
                bool genderIsUnknown = contact.Gender == Gender.Unknown;
                bool contactIsValid = !nameIsEmpty && !surnameIsEmpty && !genderIsUnknown;

                if (contactIsValid)
                {
                    yield return contact;
                }
            }
        }

        public static void ValidateDataFromSources()
        {
            var contacts = PPIJContacts.Instance.GetContacts();
            Console.WriteLine("Ukupno kontakata: " + contacts.Count());

            var validContacts = DataValidation.RemoveInvalidContacts(contacts);
            Console.WriteLine("Ukupno potpunih kontakata: " + validContacts.Count());
        }
    }
}
