﻿using System;
using System.Collections.Generic;

namespace Sorters
{
    public static partial class MergeSorter
    {
        public static IList<T> MergeSort<T>(this IList<T> array)
            where T : System.IComparable<T>
        {
            IList<T> newArray = new List<T>(array);

            if (newArray.Count > 0)
            {
                ParallelMergeSort(newArray, new List<T>(array), 0, array.Count - 1, getMaxDepth());
            }
            
            return newArray;
        }

        internal static int getMaxDepth()
        {
            return (int)Math.Log(Environment.ProcessorCount, 2) + 4;
        }
    }
}
