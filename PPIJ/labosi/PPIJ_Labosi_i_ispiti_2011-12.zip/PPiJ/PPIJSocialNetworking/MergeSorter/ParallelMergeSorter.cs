﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Sorters
{
    public static partial class MergeSorter
    {
        internal static void ParallelMergeSort<T>(IList<T> array, IList<T> tempArray, int low, int high, int depth)
            where T : System.IComparable<T>
        {
            if (depth <= 0)
            {
                SequentialMergeSort(array, tempArray, low, high);
                return;
            }

            int middle = (low + high) / 2;
            Parallel.Invoke(
                () => ParallelMergeSort(tempArray, array, low, middle, depth - 1),
                () => ParallelMergeSort(tempArray, array, middle + 1, high, depth - 1));

            Merge(array, tempArray, low, middle, middle + 1, high, low);
        }

        //internal static void ParallelMerge<T>
        //    (IList<T> array, IList<T> tempArray, int lowX, int highX, int lowY, int highY, int lowTo, int depth)
        //    where T : System.IComparable<T>
        //{
        //    var lengthX = highX - lowX + 1;
        //    var lengthY = highY - lowY + 1;

        //    if (lengthX + lengthY <= SEQUENTIAL_THRESHOLD || depth <= 0)
        //    {
        //        SequentialMerge(array, tempArray, lowX, highX, lowY, highY, lowTo);
        //        return;
        //    }

        //    if (lengthX < lengthY)
        //    {
        //        ParallelMerge(array, tempArray, lowY, highY, lowX, highX, lowTo, depth);
        //        return;
        //    }

        //    // Get median of the X sub-array. As X sub-array is 
        //    // sorted it means that X[lowX .. midX - 1] are less 
        //    // than or equal to median and X[midx + 1 .. highX] 
        //    // are greater or equal to median.
        //    var midX = (lowX + highX) / 2;
        //    // Find element in the Y sub-array that is strictly 
        //    // greater than X[midX]. Again as Y sub-array is 
        //    // sorted Y[lowY .. midY - 1] are less than or equal 
        //    // to X[midX] and Y[midY .. highY] are greater than 
        //    // X[midX].
        //    var midY = BinarySearch(tempArray, lowY, highY, tempArray[midX]);
        //    // Now we can compute final position in the target 
        //    // array of median of the X sub-array.
        //    var midTo = lowTo + midX - lowX + midY - lowY;
        //    array[midTo] = tempArray[midX];
        //    // The rest is to merge X[lowX .. midX - 1] with 
        //    // Y[lowY .. midY - 1] and X[midx + 1 .. highX] 
        //    // with Y[midY .. highY] preceeding and following 
        //    // median respectively in the target array. As 
        //    // pairs are idependent from their final position 
        //    // perspective they can be merged in parallel.
        //    Parallel.Invoke(
        //        () => ParallelMerge(array, tempArray, lowX, midX - 1, lowY, midY - 1, lowTo, depth - 1),
        //        () => ParallelMerge(array, tempArray, midX + 1, highX, midY, highY, midTo + 1, depth - 1));
        //}

        //// Searches for index the first element in low to high 
        //// range that is strictly greater than provided value 
        //// and all elements within specified range are smaller 
        //// or equal than index of the element next to range is 
        //// returned.
        //internal static int BinarySearch<T>(IList<T> array, int low, int high, T lessThanOrEqualTo)
        //    where T : System.IComparable<T>
        //{
        //    high = Math.Max(low, high + 1);

        //    while (low < high)
        //    {
        //        int middle = (low + high) / 2;

        //        if (array[middle].CompareTo(lessThanOrEqualTo) < 0)
        //        {
        //            low = middle + 1;
        //        }
        //        else
        //        {
        //            high = middle;
        //        }
        //    }

        //    return low;
        //}

        //internal const int SEQUENTIAL_THRESHOLD = 0; // 2048
    }
}
