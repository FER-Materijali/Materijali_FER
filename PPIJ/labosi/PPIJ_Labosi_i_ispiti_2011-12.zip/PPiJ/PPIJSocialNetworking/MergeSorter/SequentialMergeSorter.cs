﻿using System.Collections.Generic;

namespace Sorters
{
    public static partial class MergeSorter
    {
        internal static void SequentialMergeSort<T>(IList<T> array, IList<T> tempArray, int low, int high)
            where T : System.IComparable<T>
        {
            if (low < high)
            {
                int middle = (low + high) / 2;
                SequentialMergeSort(tempArray, array, low, middle);
                SequentialMergeSort(tempArray, array, middle + 1, high);
                Merge(array, tempArray, low, middle, middle + 1, high, low);
            }
        }

        internal static void Merge<T>
            (IList<T> array, IList<T> tempArray, int lowX, int highX, int lowY, int highY, int lowTo)
            where T : System.IComparable<T>
        {
            int highTo = lowTo + highX - lowX + highY - lowY + 1;
            for (; lowTo <= highTo; lowTo++)
            {
                if (lowX > highX)
                {
                    array[lowTo] = tempArray[lowY++];
                }
                else if (lowY > highY)
                {
                    array[lowTo] = tempArray[lowX++];
                }
                else
                {
                    array[lowTo] = tempArray[lowX].CompareTo(tempArray[lowY]) < 0
                                    ? tempArray[lowX++]
                                    : tempArray[lowY++];
                }
            }
        }
    }
}
