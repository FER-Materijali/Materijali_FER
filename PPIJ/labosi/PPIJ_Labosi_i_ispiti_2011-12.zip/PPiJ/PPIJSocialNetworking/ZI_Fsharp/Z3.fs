﻿open System

let rec CountNamesEnding (prezimenaList : List<String>) (niz : String) = 
    match prezimenaList with
    | [] -> 0
    | prezime::ostatakListe ->
         Convert.ToInt32(prezime.EndsWith(niz)) + CountNamesEnding ostatakListe niz

//printfn "%d" (CountNamesEnding ["1a"; "2a"; "1b"] "a")

let Prezimena = ["Brankov"; "Markov"; "Gavran"; "Tulj"]
let Zavrseci = ["ov"; "na"]

let CheckEndings = 
    let mutable brojPrezimena = 0
    for zavrsetak in Zavrseci do
        brojPrezimena <- brojPrezimena + CountNamesEnding Prezimena zavrsetak
    printfn "%d" brojPrezimena