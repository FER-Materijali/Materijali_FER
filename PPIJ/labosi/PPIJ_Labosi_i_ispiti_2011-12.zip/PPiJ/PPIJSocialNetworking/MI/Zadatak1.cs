﻿using System;
using System.Text.RegularExpressions;

namespace MI
{
    #region Putanja

    public abstract class Putanja
    {
        public string Naziv { get; protected set; }

        public Putanja(string naziv)
        {
            Naziv = naziv;
        }
    }

    public class LokalnaPutanja : Putanja
    {
        public LokalnaPutanja(string naziv)
            : base(naziv)
        { }
    }

    public class MreznaPutanja : Putanja
    {
        public MreznaPutanja(string naziv)
            : base(naziv)
        { }
    }

    #endregion

    #region Postavke

    public static class Postavke
    {
        public static Putanja PutanjaDnevnika { get; set; }
    }

    #endregion

    #region Tvornica

    public class PutanjaTvornica
    {
        public Putanja StvoriPutanju(string putanja)
        {
            Putanja novaPutanja;

            if (jeLokalnaPutanja(putanja))
            {
                novaPutanja = new LokalnaPutanja(putanja);
            }
            else if (jeMreznaPutanja(putanja))
            {
                novaPutanja = new MreznaPutanja(putanja);
            }
            else
            {
                throw new NeispravnaPutanjaException();
            }

            return novaPutanja;
        }

        protected bool jeLokalnaPutanja(string putanja)
        {
            // regularni izraz nije dobar
            return Regex.IsMatch(putanja, @"[a-zA-Z]:\\[^/?*:;{}\\]*"); ;
        }

        protected bool jeMreznaPutanja(string putanja)
        {
            // takoder nije dobar :)
            return Regex.IsMatch(putanja, @"\\\\([^/?.*:;{}\\]+)(\\[^/?*:;{}\\]+)*");
        }
    }

    #endregion

    #region Exception

    public class NeispravnaPutanjaException : ArithmeticException
    {
        public override string Message
        {
            get { return "Neispravna putanja"; }
        }

    }

    #endregion
}
