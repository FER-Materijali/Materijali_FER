﻿using System;
using System.IO;
using System.Text;
using PostSharp.Aspects;

namespace MI
{
    [Serializable]
    public sealed class Log : OnExceptionAspect
    {
        private const string logDatoteka = "Log.txt";
        private string logPath
        {
            get 
            {
                return Path.Combine(Postavke.PutanjaDnevnika.Naziv, logDatoteka);
            }
        }

        public override void OnException(MethodExecutionArgs args)
        {
            StringBuilder message = new StringBuilder();

            message.AppendLine("Error " + DateTime.Now.ToUniversalTime());
            message.AppendLine(" Ime metode: " + args.Method.Name);
            message.AppendLine(" Tip pogreške: " + args.Exception.GetType().Name);
            message.AppendLine(" Poruka pogreške: " + args.Exception.Message);
            message.AppendLine();

            using (StreamWriter sw = File.AppendText(logPath))
            {
                sw.WriteLine(message.ToString());
            }

            args.FlowBehavior = FlowBehavior.Default;
        }
    }
}
