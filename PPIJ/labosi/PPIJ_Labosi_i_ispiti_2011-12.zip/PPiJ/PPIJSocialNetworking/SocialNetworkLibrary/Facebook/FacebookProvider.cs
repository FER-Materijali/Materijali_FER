﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using PPIJServicesLibrary;
using SocialNetworkLibrary.Properties;

namespace SocialNetworkLibrary
{
    public class FacebookProvider : NetworkProvider
    {
        /// <summary>
        ///     The single instance of FacebookProvider class.
        /// </summary>
        static readonly FacebookProvider instance = new FacebookProvider();
        public static FacebookProvider Instance
        {
            get
            {
                return instance;
            }
        }

        private FacebookTokens facebookTokens { get; set; }

        /// <summary>
        ///     Private constructor to prevent creating instances of
        ///     this class. Loads FacebookTokens from the configuration 
        ///     file.
        /// </summary>
        private FacebookProvider()
        {
            facebookTokens = getFacebookTokens();
        }

        /// <summary>
        ///     Sends the message to Facebook.
        /// </summary>
        public override SendMessageStatus Send(Message message)
        {
            FacebookMessage facebookMessage = message as FacebookMessage;

            if (facebookMessage == null)
            {
                return new SendMessageFail("Message can't be send to Facebook!");
            }

            if (FacebookService.Post(facebookTokens, facebookMessage.MessageBody))
            {
                return new SendMessageSuccess("Message has been successfully send to Facebook.");
            }
            else
            {
                return new SendMessageFail("Message has NOT been successfully send to Facebook!");
            }
        }

        /// <summary>
        ///     Gets the authorization Uri for connecting to a new
        ///     facebook account.
        /// </summary>
        /// <returns>
        ///     A new authorization Uri.
        /// </returns>
        public Uri AuthorizationUri
        {
            get
            {
                string scope = "read_friendlists,user_status,publish_stream";
                return new Uri(FacebookService.GetAuthorizationUri(facebookTokens.APIKey, scope));
            }
        }

        /// <summary>
        ///     Authorizes a new user.
        /// </summary>
        /// <param name="responseUri">
        ///     Url that contains the access token.
        /// </param>
        /// <returns>
        ///     True if the user is successfully authorized,
        ///     otherwise false.
        /// </returns>
        public bool AuthorizeUser(Uri responseUri)
        {
            try
            {
                // try to get the access token for this user
                string accessToken = FacebookService.GetAccessToken(responseUri);
                facebookTokens.AccessToken = accessToken;
                saveFacebookTokens();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        ///     Gets facebook tokens.
        /// </summary>
        private FacebookTokens getFacebookTokens()
        {
            return readFacebookTokensFromFile();
        }

        /// <summary>
        ///     Saves facebook tokens.
        /// </summary>
        private void saveFacebookTokens()
        {
            saveFacebookTokensToFile();
        }

        /// <summary>
        ///     Reads facebook tokens from the configuration file.
        /// </summary>
        private FacebookTokens readFacebookTokensFromFile()
        {
            if (!File.Exists(configurationFile))
            {
                createDefaultConfFile();
            }

            XElement xmlTokens = XDocument.Load(configurationFile)
                                          .Element("Facebook");

            FacebookTokens tokens = new FacebookTokens()
            {
                APIKey = xmlTokens.Element("APIKey")
                                    .Attribute("value").Value,
                SecretKey = xmlTokens.Element("SecretKey")
                                    .Attribute("value").Value,
                AccessToken = xmlTokens.Element("AccessToken")
                                    .Attribute("value").Value
            };

            return tokens;
        }

        /// <summary>
        ///     Saves the current facebook tokens to the configuration file.
        /// </summary>
        private void saveFacebookTokensToFile()
        {
            XElement xmlTokens = new XElement("Facebook",
                new XElement("APIKey",
                    new XAttribute("value", facebookTokens.APIKey)),
                new XElement("SecretKey",
                    new XAttribute("value", facebookTokens.SecretKey)),
                new XElement("AccessToken",
                    new XAttribute("value", facebookTokens.AccessToken)));

            xmlTokens.Save(configurationFile, SaveOptions.None);
        }

        /// <summary>
        ///     Path of the xml configuration file.
        /// </summary>
        private string configurationFile
        {
            get
            {
                return Path.Combine(Environment.GetFolderPath(
                    Environment.SpecialFolder.LocalApplicationData), "FacebookConfiguration.xml");
            }
        }

        /// <summary>
        ///     Creates a new empty configuration file if one doesn't
        ///     already exist.
        /// </summary>
        private void createDefaultConfFile()
        {
            XElement xmlTokens = new XElement("Facebook",
                new XElement("APIKey",
                    new XAttribute("value", Settings.Default.facebookAPIKey)),
                new XElement("SecretKey",
                    new XAttribute("value", Settings.Default.facebookSecretKey)),
                new XElement("AccessToken",
                    new XAttribute("value", string.Empty)));

            xmlTokens.Save(configurationFile, SaveOptions.None);
        }

        public override List<UserProfile> GetUsers()
        {
            List<UserProfile> users = new List<UserProfile>();

            try
            {
                FacebookService.GetFriends(facebookTokens)
                    .Select(u => u as UserProfile).ToList();
            }
            catch (Exception)
            { }

            return users;
        }
    }
}
