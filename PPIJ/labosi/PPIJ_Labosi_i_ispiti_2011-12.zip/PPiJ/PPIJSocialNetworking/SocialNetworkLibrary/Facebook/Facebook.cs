﻿namespace SocialNetworkLibrary
{
    /// <summary>
    ///     Social network - Facebook.
    /// </summary>
    public class Facebook : SocialNetwork
    {
        public override string Name
        {
            get { return "Facebook"; }
        }

        internal override NetworkProvider Provider
        {
            get { return FacebookProvider.Instance; }
        }

        public Facebook(IMessageForm registeredForm)
            : base(registeredForm)
        { }

        /// <summary>
        ///     Extracts a new facebook message from a form that 
        ///     implements the IMessageForm interface.
        /// </summary>
        protected override Message extractMessage(IMessageForm form)
        {
            Message message = new FacebookMessage(form.MessageBody);
            return message;
        }
    }
}
