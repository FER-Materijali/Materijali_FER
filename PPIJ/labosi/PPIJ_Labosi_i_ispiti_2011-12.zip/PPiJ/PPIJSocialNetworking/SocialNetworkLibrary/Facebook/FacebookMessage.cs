﻿namespace SocialNetworkLibrary
{
    /// <summary>
    ///     Facebook message.
    /// </summary>
    class FacebookMessage : Message
    {
        /// <summary>
        ///     Creates a new facebook message.
        /// </summary>
        public FacebookMessage(string messageBody)
            : base(messageBody, string.Empty)
        { }
    }
}
