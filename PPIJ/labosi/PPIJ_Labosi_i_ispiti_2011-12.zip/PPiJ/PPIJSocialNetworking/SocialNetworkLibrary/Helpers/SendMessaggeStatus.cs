﻿using System.Windows.Forms;

namespace SocialNetworkLibrary
{
    /// <summary>
    ///     Represents an abstract status returned after sending a message.
    /// </summary>
    public abstract class SendMessageStatus
    {
        /// <summary>
        ///     Status description.
        /// </summary>
        public string StatusText { get; protected set; }

        public SendMessageStatus(string statusText)
        {
            StatusText = statusText;
        }

        /// <summary>
        ///     Shows a MessageBox for this status.
        /// </summary>
        public abstract void ShowStatusMessageBox();
    }

    /// <summary>
    ///     Returned if send message succeded.
    /// </summary>
    public sealed class SendMessageSuccess : SendMessageStatus
    {
        public SendMessageSuccess(string statusText)
            : base(statusText) { }

        public override void ShowStatusMessageBox()
        {
            MessageBox.Show(
                StatusText, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    /// <summary>
    ///     Returned if send message failed.
    /// </summary>
    public sealed class SendMessageFail : SendMessageStatus
    {
        public SendMessageFail(string statusText)
            : base(statusText) { }

        public override void ShowStatusMessageBox()
        {
            MessageBox.Show(
                StatusText, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}