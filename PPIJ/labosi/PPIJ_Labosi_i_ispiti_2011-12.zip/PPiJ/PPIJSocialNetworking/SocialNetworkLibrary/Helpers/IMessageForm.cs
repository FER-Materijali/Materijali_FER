﻿namespace SocialNetworkLibrary
{
    public interface IMessageForm
    {
        string Author { get; }
        string MessageBody { get; }
        string Reply { get; }

        void RegisterNetwork(SocialNetwork network);
    }
}
