﻿namespace SocialNetworkLibrary
{
    /// <summary>
    ///     PPiJBoard message.
    /// </summary>
    public class PPiJBoardMessage : Message
    {
        /// <summary>
        ///     Hides the inherited string Reply value and replaces it
        ///     with a nullable int - id of the message to reply or null.
        /// </summary>
        public new int? Reply { get; set; }

        /// <summary>
        ///     Creates a new istance of PPiJBoardMessage.
        /// </summary>
        public PPiJBoardMessage(string messageBody, string author, string reply = null)
            : base(messageBody, author, reply)
        {
            if (!string.IsNullOrEmpty(reply))
            {
                int replyTo;
                if (int.TryParse(reply, out replyTo))
                {
                    Reply = replyTo;
                }
            }
        }
    }
}
