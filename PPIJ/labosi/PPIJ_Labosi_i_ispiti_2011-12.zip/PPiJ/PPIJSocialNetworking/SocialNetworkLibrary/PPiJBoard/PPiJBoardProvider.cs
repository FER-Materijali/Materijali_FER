﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using PPIJServicesLibrary;
using SocialNetworkLibrary.Properties;

namespace SocialNetworkLibrary
{
    public sealed class PPiJBoardProvider : NetworkProvider
    {
        /// <summary>
        ///     The single instance of PPiJBoardProvider class.
        /// </summary>
        static readonly PPiJBoardProvider instance = new PPiJBoardProvider();
        public static PPiJBoardProvider Instance
        {
            get
            {
                return instance;
            }
        }

        private string ppijApplicationKey { get; set; }

        private string _ppijAccessToken;
        private string ppijAccessToken 
        {
            get
            {
                // access tokens expires every 5 minutes and it
                // needs to be updated
                refreshAccessToken();
                return _ppijAccessToken;
            }
            set
            {
                _ppijAccessToken = value;
            }
        }

        /// <summary>
        ///     Private constructor to prevent creating instances of
        ///     this class. Loads the Application Key from the 
        ///     configuration file.
        /// </summary>
        private PPiJBoardProvider()
        {
            ppijApplicationKey = getApplicationKey();
            ppijAccessToken = getAccessToken();
        }

        /// <summary>
        ///     Sends the message to PPiJBoard.
        /// </summary>
        public override SendMessageStatus Send(Message message)
        {
            PPiJBoardMessage ppijBoardMessage = message as PPiJBoardMessage;

            if (ppijBoardMessage == null)
            {
                return new SendMessageFail("Message can't be send to PPiJBoard!");
            }

            try
            {
                if (message.IsReply)
                {
                    PPIJBoardService.PostReply(ppijAccessToken, 
                        ppijBoardMessage.Author, ppijBoardMessage.MessageBody, ppijBoardMessage.Reply);
                }
                else
                {
                    PPIJBoardService.PostMessage(ppijAccessToken, 
                        ppijBoardMessage.Author, ppijBoardMessage.MessageBody);
                }

                return new SendMessageSuccess("Message has been successfully send to PPiJBoard!");
            }
            catch (Exception)
            {
                return new SendMessageFail("Message has NOT been successfully send to PPiJBoard!");
            }
        }

        /// <summary>
        ///     Trys to get a new access token from PPIJBoardService.
        /// </summary>
        private void refreshAccessToken()
        {
            try
            {
                // try to get a new access token
                string token = PPIJBoardService.GetAccessToken(ppijApplicationKey);

                // save the new token
                ppijAccessToken = token;
                saveAccessToken();
            }
            catch (Exception)
            {
                // most likely there exist a valid access token
            }
        }

        /// <summary>
        ///     Gets the application key.
        /// </summary>
        private string getApplicationKey()
        {
            return getApplicationKeyFromFile();
        }

        /// <summary>
        ///     Gets the access token.
        /// </summary>
        private string getAccessToken()
        {
            return getAccessTokenFromFile();
        }

        /// <summary>
        ///     Saves the access token.
        /// </summary>
        private void saveAccessToken()
        {
            saveAccessTokenToFile();
        }

        /// <summary>
        ///     Reads the application key from a configuration file.
        /// </summary>
        private string getApplicationKeyFromFile()
        {
            if (!File.Exists(configurationFile))
            {
                createDefaultConfFile();
            }

            return XDocument.Load(configurationFile)
                            .Element("PPiJBoard")
                            .Element("ApplicationKey")
                            .Attribute("value").Value;
        }

        /// <summary>
        ///     Reads the access token from a configuration file.
        /// </summary>
        /// <returns></returns>
        private string getAccessTokenFromFile()
        {
            if (!File.Exists(configurationFile))
            {
                createDefaultConfFile();
            }

            return XDocument.Load(configurationFile)
                            .Element("PPiJBoard")
                            .Element("AccessToken")
                            .Attribute("value").Value;
        }

        /// <summary>
        ///     Saves the current access token to the configuration file.
        /// </summary>
        private void saveAccessTokenToFile()
        {
            XElement xmlTokens = new XElement("PPiJBoard",
                new XElement("ApplicationKey",
                    new XAttribute("value", ppijApplicationKey)),
                new XElement("AccessToken",
                    new XAttribute("value", _ppijAccessToken)));

            xmlTokens.Save(configurationFile, SaveOptions.None);
        }

        /// <summary>
        ///     Path of the xml configuration file.
        /// </summary>
        private string configurationFile
        {
            get
            {
                return Path.Combine(Environment.GetFolderPath(
                    Environment.SpecialFolder.LocalApplicationData), "PPiJBoardConfiguration.xml");
            }
        }

        /// <summary>
        ///     Creates a new empty configuration file if one doesn't
        ///     already exist.
        /// </summary>
        private void createDefaultConfFile()
        {
            XElement xmlTokens = new XElement("PPiJBoard",
                new XElement("ApplicationKey",
                    new XAttribute("value", Settings.Default.ppijApplicationKey)),
                new XElement("AccessToken",
                    new XAttribute("value", string.Empty)));

            xmlTokens.Save(configurationFile, SaveOptions.None);
        }

        public override List<UserProfile> GetUsers()
        {
            List<UserProfile> users = new List<UserProfile>();

            try
            {
                users = PPIJBoardService.GetUsers(ppijAccessToken)
                    .Select(u => u as UserProfile).ToList();
            }
            catch (Exception)
            { }

            return users;
        }
    }
}