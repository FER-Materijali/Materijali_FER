﻿using PPIJServicesLibrary;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Windows;

namespace SocialNetworkLibrary
{
    /// <summary>
    ///     Social network - PPiJBoard.
    /// </summary>
    public class PPiJBoard : SocialNetwork
    {
        public override string Name
        {
            get { return "PPiJBoard"; }
        }

        internal override NetworkProvider Provider
        {
            get { return PPiJBoardProvider.Instance; }
        }

        public PPiJBoard(IMessageForm registeredForm)
            : base(registeredForm)
        { }

        /// <summary>
        ///     Extracts a new PPiJBoard message from a form that 
        ///     implements the IMessageForm interface.
        /// </summary>
        protected override Message extractMessage(IMessageForm form)
        {
            Message message = 
                new PPiJBoardMessage(form.MessageBody, form.Author, form.Reply);
            return message;
        }
    }
}