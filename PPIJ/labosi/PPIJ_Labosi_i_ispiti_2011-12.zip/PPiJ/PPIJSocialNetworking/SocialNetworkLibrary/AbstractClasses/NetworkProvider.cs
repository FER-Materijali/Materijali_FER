﻿using System.Collections.Generic;
using PPIJServicesLibrary;

namespace SocialNetworkLibrary
{
    /// <summary>
    ///     Represents an abstract social network provider.
    /// </summary>
    public abstract class NetworkProvider
    {
        /// <summary>
        ///     Sends the message to the network.
        /// </summary>
        /// <returns>
        ///     Send message status indicating was the message
        ///     successfully send.
        /// </returns>
        public abstract SendMessageStatus Send(Message message);

        /// <summary>
        ///     Gets all users from the network.
        /// </summary>
        public abstract List<UserProfile> GetUsers();
    }
}
