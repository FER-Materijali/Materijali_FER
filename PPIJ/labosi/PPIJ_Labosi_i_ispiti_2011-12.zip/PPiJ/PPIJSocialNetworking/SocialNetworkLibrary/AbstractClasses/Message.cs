﻿namespace SocialNetworkLibrary
{
    /// <summary>
    ///     Abstract social network message.
    /// </summary>
    public abstract class Message
    {
        /// <summary>
        ///     Message author.
        /// </summary>
        public string Author { get; set; }

        /// <summary>
        ///     Message body.
        /// </summary>
        public string MessageBody { get; set; }

        /// <summary>
        ///     If this message is a response to another message, string value
        ///     that identifies the other message, otherwise null.
        /// </summary>
        public string Reply { get; set; }

        /// <summary>
        ///     True if this message is a response to another message,
        ///     otherwise false.
        /// </summary>
        public bool IsReply
        {
            get
            {
                return Reply != null;
            }
        }

        /// <summary>
        ///     Creates a new Message.
        /// </summary>
        /// <param name="messageBody">
        ///     Body of the message.
        /// </param>
        /// <param name="author">
        ///     Author of the message.
        /// </param>
        /// <param name="reply">
        ///     If this message is a response to another message, string value
        ///     that identifies the other message.
        /// </param>
        public Message(string messageBody, string author, string reply = null)
        {
            MessageBody = messageBody;
            Author = author;
            Reply = reply;
        }
    }
}
