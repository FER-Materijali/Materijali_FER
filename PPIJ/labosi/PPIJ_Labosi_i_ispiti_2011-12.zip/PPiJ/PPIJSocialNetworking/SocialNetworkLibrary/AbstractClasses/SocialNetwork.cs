﻿using PPIJServicesLibrary;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Windows;

namespace SocialNetworkLibrary
{
    /// <summary>
    ///     Represents an abstract social network.
    /// </summary>
    public abstract class SocialNetwork
    {
        /// <summary>
        ///     Name of the social network.
        /// </summary>
        public abstract string Name { get; }

        /// <summary>
        ///     A wrapper around the social network.
        /// </summary>
        internal abstract NetworkProvider Provider { get; }

        /// <summary>
        ///     Form to which this network is registered.
        /// </summary>
        internal IMessageForm RegisteredForm { get; private set; }

        public List<UserProfile> Users
        {
            get
            {
                return Provider.GetUsers();
            }
        }

        /// <summary>
        ///     Creates a new instance of the social network and
        ///     registers it to the specified form.
        /// </summary>
        public SocialNetwork(IMessageForm registeredForm)
        {
            RegisteredForm = registeredForm;
            RegisteredForm.RegisterNetwork(this);
        }

        /// <summary>
        ///     Sends the message to a social network.
        /// </summary>
        /// <returns>
        ///     Send message status indicating was the message
        ///     successfully send to the network.
        /// </returns>
        public SendMessageStatus SendMessage(IMessageForm form)
        {
            Message message = extractMessage(form);
            return Provider.Send(message);
        }

        /// <summary>
        ///     Extracts a new message from a form that 
        ///     implements the IMessageForm interface.
        /// </summary>
        protected abstract Message extractMessage(IMessageForm form);

        public override string ToString()
        {
            return Name;
        }
    }
}
