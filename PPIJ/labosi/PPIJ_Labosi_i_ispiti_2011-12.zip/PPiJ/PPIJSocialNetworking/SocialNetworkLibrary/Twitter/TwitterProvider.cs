﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using PPIJServicesLibrary;
using SocialNetworkLibrary.Properties;

namespace SocialNetworkLibrary
{
    public sealed class TwitterProvider : NetworkProvider
    {
        /// <summary>
        ///     The single instance of TwitterProvider class.
        /// </summary>
        static readonly TwitterProvider instance = new TwitterProvider();
        public static TwitterProvider Instance
        {
            get
            {
                return instance;
            }
        }

        private TwitterTokens twitterTokens { get; set; }
        private string requestToken { get; set; }

        /// <summary>
        ///     Private constructor to prevent creating instances of
        ///     this class. Loads TwitterTokens from the configuration 
        ///     file.
        /// </summary>
        private TwitterProvider()
        {
            twitterTokens = getTwitterTokens();
        }

        /// <summary>
        ///     Sends the message to Twitter.
        /// </summary>
        public override SendMessageStatus Send(Message message)
        {
            TwitterMessage twitterMessage = message as TwitterMessage;

            if (twitterMessage == null)
            {
                return new SendMessageFail("Message can't be send to Twitter!");
            }

            if (TwitterService.Tweet(twitterTokens, twitterMessage.MessageBody))
            {
                return new SendMessageSuccess("Message has been successfully send to Twitter.");
            }
            else
            {
                return new SendMessageFail("Message has NOT been successfully send to Twitter!");
            }
        }

        /// <summary>
        ///     Gets the authorization URL for connecting to a new
        ///     twitter account.
        /// </summary>
        /// <returns>
        ///     A new authorization URL.
        /// </returns>
        public string AuthorizationURL
        {
            get
            {
                requestToken = TwitterService.GetRequestToken(
                    twitterTokens.ConsumerKey, twitterTokens.ConsumerSecret);
                return TwitterService.GetAuthorizationUri(requestToken);
            }
        }

        /// <summary>
        ///     Authorizes a new user.
        /// </summary>
        /// <param name="pin">
        ///     Generated PIN that matches the requestToken.
        /// </param>
        /// <returns>
        ///     True if the user is successfully authorized,
        ///     otherwise false.
        /// </returns>
        public bool AuthorizeUser(string pin)
        {
            try
            {
                // try to get the access token for this user
                var tokens = TwitterService.GetAccessToken(
                    twitterTokens.ConsumerKey, twitterTokens.ConsumerSecret, requestToken, pin);

                twitterTokens = tokens;
                saveTwitterTokens();
                return true;
            }
            catch (Exception) // most likely wrong pin
            {
                // request token can be used only once
                requestToken = null;
                return false;
            }
        }

        /// <summary>
        ///     Gets twitter tokens.
        /// </summary>
        private TwitterTokens getTwitterTokens()
        {
            return readTwitterTokensFromFile();
        }

        /// <summary>
        ///     Saves twitter tokens.
        /// </summary>
        private void saveTwitterTokens()
        {
            saveTwitterTokensToFile();
        }

        /// <summary>
        ///     Reads twitter tokens from the configuration file.
        /// </summary>
        private TwitterTokens readTwitterTokensFromFile()
        {
            if (!File.Exists(configurationFile))
            {
                createDefaultConfFile();
            }

            XElement xmlTokens = XDocument.Load(configurationFile)
                                          .Element("Twitter");

            TwitterTokens tokens = new TwitterTokens()
            {
                ConsumerKey = xmlTokens.Element("ConsumerKey")
                                .Attribute("value").Value,
                ConsumerSecret =  xmlTokens.Element("ConsumerSecret")
                                    .Attribute("value").Value,
                AccessToken = xmlTokens.Element("AccessToken")
                                .Attribute("value").Value,
                AccessTokenSecret = xmlTokens.Element("AccessTokenSecret")
                                        .Attribute("value").Value
            };
            
            return tokens;
        }

        /// <summary>
        ///     Saves the current twitter tokens to the configuration file.
        /// </summary>
        private void saveTwitterTokensToFile()
        {
            XElement xmlTokens = new XElement("Twitter",
                new XElement("ConsumerKey", 
                    new XAttribute("value", twitterTokens.ConsumerKey)),
                new XElement("ConsumerSecret",
                    new XAttribute("value", twitterTokens.ConsumerSecret)),
                new XElement("AccessToken",
                    new XAttribute("value", twitterTokens.AccessToken)),
                new XElement("AccessTokenSecret",
                    new XAttribute("value", twitterTokens.AccessTokenSecret)));

            xmlTokens.Save(configurationFile, SaveOptions.None);
        }

        /// <summary>
        ///     Path of the xml configuration file.
        /// </summary>
        private string configurationFile
        {
            get
            {
                return Path.Combine(Environment.GetFolderPath(
                    Environment.SpecialFolder.LocalApplicationData), "TwitterConfiguration.xml");
            }
        }

        /// <summary>
        ///     Creates a new empty configuration file if one doesn't
        ///     already exist.
        /// </summary>
        private void createDefaultConfFile()
        {
            XElement xmlTokens = new XElement("Twitter",
                new XElement("ConsumerKey",
                    new XAttribute("value", Settings.Default.twitterConsumerKey)),
                new XElement("ConsumerSecret",
                    new XAttribute("value", Settings.Default.twitterConsumerSecret)),
                new XElement("AccessToken",
                    new XAttribute("value", string.Empty)),
                new XElement("AccessTokenSecret",
                    new XAttribute("value", string.Empty)));

            xmlTokens.Save(configurationFile, SaveOptions.None);
        }

        public override List<UserProfile> GetUsers()
        {
            List<UserProfile> users = new List<UserProfile>();

            try
            {
                users = TwitterService.GetFollowers(twitterTokens)
                    .Select(f => f as UserProfile).ToList();
            }
            catch (Exception)
            { }

            return users;
        }
    }
}
