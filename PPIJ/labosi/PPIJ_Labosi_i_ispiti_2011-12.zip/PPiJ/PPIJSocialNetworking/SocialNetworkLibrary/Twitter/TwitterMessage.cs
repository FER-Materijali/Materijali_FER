﻿namespace SocialNetworkLibrary
{
    /// <summary>
    ///     Twitter message.
    /// </summary>
    public class TwitterMessage : Message
    {
        /// <summary>
        ///     Creates a new twitter message.
        /// </summary>
        public TwitterMessage(string messageBody)
            : base(messageBody, string.Empty)
        { }
    }
}
