﻿using System.Windows;
using System.Windows.Forms;
using PPIJServicesLibrary;

namespace SocialNetworkLibrary
{
    /// <summary>
    ///     Social network - Twitter.
    /// </summary>
    public class Twitter : SocialNetwork
    {
        public override string Name
        {
            get { return "Twitter"; }
        }

        internal override NetworkProvider Provider
        {
            get { return TwitterProvider.Instance; }
        }

        public Twitter(IMessageForm registeredForm)
            : base(registeredForm)
        { }

        /// <summary>
        ///     Extracts a new twitter message from a form that 
        ///     implements the IMessageForm interface.
        /// </summary>
        protected override Message extractMessage(IMessageForm form)
        {
            Message message = new TwitterMessage(form.MessageBody);
            return message;
        }
    }
}
