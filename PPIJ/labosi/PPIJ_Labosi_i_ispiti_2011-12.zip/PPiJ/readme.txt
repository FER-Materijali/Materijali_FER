Solution sadr�i prvi i drugi labos, MI i ZI iz kolegija PPiJ 2011/2012.

Potrebno je u datoteci Properties/Settings projekta SocialNetworkLibrary definirati sve varijable da bi program radio za neku mre�u.
Kako dobiti navedene klju�eve je opisano u PDF datotekama Priprema_1_DZ_1Lab i Priprema_2_DZ_2Lab.