s=tf('s')
G=0.03*1/(s*(0.0125*s+1))
Kp=221;
Ki=60;
Kd=10;
C=pid(Kp,Ki,Kd);
Gp=feedback(C*G,1);
step(Gp)