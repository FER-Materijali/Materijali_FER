^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package hector_gazebo_worlds
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.3 (2014-05-27)
------------------

0.3.2 (2014-03-30)
------------------
* added missing install rule
* Contributors: Johannes Meyer

0.3.1 (2013-09-23)
------------------

0.3.0 (2013-09-02)
------------------
* Catkinization of stack hector_gazebo
