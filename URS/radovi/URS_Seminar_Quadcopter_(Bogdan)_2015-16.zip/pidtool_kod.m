s=tf('s');

% konstante
Tm=0.0125;
Ixx=0.01152;
Iyy=0.01152;
Izz=0.0218;
bf=8.54858e-06;
bm=0.016;
l=0.18;
m=1.477;
omega0=650.84;

% definicija prijenosne funkcije kojoj treba regulator
%  num=8*omega0*bf;
%  den=m*Tm*s^2+m*s;
%  sys=num/den;
 
% num=1+4*Tm*s;
%  den=8*Tm^4*s^3+8*Tm^2*s^3+4*Tm*s^2+s;
%  sys=num/den;
% % pozivanje toolboxa
% % pzmap(sys)
% 
% C= pidtune(sys,'PID');