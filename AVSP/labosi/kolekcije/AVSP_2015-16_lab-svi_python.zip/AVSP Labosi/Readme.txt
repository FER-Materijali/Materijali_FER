﻿Ukupno 28.8/35 bodova.

1. Labos - ograničenje A 10 sekundi B 300 sekundi
1A točno
1B greška je bila u int(text_num)-1, 64. linija, treba biti int(text_num) bez -1, ispravio asistent, točnost nepoznata

2. Labos - ograničenje 200 sekundi
5.6/7, greška objašnjena u službenoj obavijesti
INFO: Poštovani, umjesto da odgovaramo svima pojedinačno tu ćemo sažeto napisati da:
    Izlaz u testu tiny4 nije pogrešan
    Evaluaciju nema smisla ponavljati jer je ispravno provedena, rezultati bi bili jednaki i da ponovimo
    P označava broj kandidata za česte parove, što je samo nužan uvjet da par bude čest, ne i dovoljan uvjet
    U pripremi piše A ≤ P ≤ n što je pogrešno, treba biti n ≤ P ≤ A, međutim smatramo da je smisao algoritma jasan iz pseudokoda pa ovu primjedbu ne možemo uvažiti
    Trebalo je u dodatnom prolazu provjeriti da kandidati za česte parove zaista i jesu česti parovi (pogledajte pseudokod algoritma iz teksta zadatka vježbe)

3. Labos - ograničenja A 60 sekundi B 10 sekundi
3A točno
3B najveći primjer probija vremensko ograničenje, potrebna optimizacija

4. Labos - ograničenje 20 sekundi, 10^5 ulaza
Sve točno

VAŽNO
Labos pisan u Pythonu 2.7, kao što vidite iz kodova nisam dobar programer, puno zakomentiranog koda dok sam pisao kod za testiranje varijabla, nitko mi nije rekao za Pycharm :)
U svakom folderu su zadaci, moji kodovi i primjeri koji su nam oni dali za provjeru.
Izlazi se provjeravaju s FC na windowsima, izlaz mora biti
Comparing files R.out and MyR.out
FC: no differences encountered

Nek vam ovi kodovi služe kao uvid u logiku, ne kao dobar kod. I provjeravaju plagijate!