package j0036474117.android.fer.hr;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class FormActivity extends AppCompatActivity {
    private EditText etFirstVariable;
    private EditText etSecondVariable;
    public static final String EXTRAS_VARA = "varA";
    public static final String EXTRAS_VARB = "varB";
    Button btnCalculate;
    TextView tvSum;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        btnCalculate = (Button) findViewById(R.id.btnCalculate);

        etFirstVariable = (EditText) findViewById(R.id.etFirstNumber);
        etSecondVariable = (EditText) findViewById(R.id.etSecondNumber);

        tvSum = (TextView) findViewById(R.id.tvSum);



        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String variableA = etFirstVariable.getText().toString();

                String variableB = etSecondVariable.getText().toString();
                int varA = 0;
                try {
                    varA = Integer.parseInt(variableA);

                } catch (Exception e) {

                }
                int varB = 0;
                try {
                    varB = Integer.parseInt(variableB);
                }catch(Exception e) {

                }

                Intent i = new Intent(FormActivity.this, CalculusActivity.class);

                i.putExtra(EXTRAS_VARA, varA);
                i.putExtra(EXTRAS_VARB, varB);
                startActivityForResult(i, 666);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode==666 && resultCode==RESULT_OK && data!=null) {
            int suma = data.getIntExtra(CalculusActivity.EXTRAS_SUM, 0);
            tvSum.setText(String.valueOf(suma));
        }
    }
}
