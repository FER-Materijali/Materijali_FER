from ctypes import *
import struct
import array

class ImageDosHeader(Structure):
    _fields_ = [
        ('e_magic', c_uint16),
        ('e_cblp', c_uint16),
        ('e_cp', c_uint16),
        ('e_crlc', c_uint16),
        ('e_cparhdr', c_uint16),
        ('e_minalloc', c_uint16),
        ('e_maxalloc', c_uint16),
        ('e_ss', c_uint16),
        ('e_sp', c_uint16),
        ('e_csum', c_uint16),
        ('e_ip', c_uint16),
        ('e_cs', c_uint16),
        ('e_lfarlc', c_uint16),
        ('e_ovno', c_uint16),
        ('e_res', c_uint16 * 4),
        ('e_oemid', c_uint16),
        ('e_oeminfo', c_uint16),
        ('e_res2', c_uint16 * 10),
        ('e_lfanew', c_uint32),
    ]
    
class PEHeader(Structure):   
    _fields_ = [
        ('pe_signature', c_uint32),
        ('machine', c_uint16),
        ('sections', c_uint16),
        ('timestamp', c_uint32),
        ('symbolpointer', c_uint32),
        ('symbolnumber', c_uint32),
        ('sizeofoptional', c_uint16),
        ('characteristics', c_uint16),
    ]
    
class ImageOptionalHeader(Structure):   
    _fields_ = [
        ('io_header', c_uint16),
        ('MajorLinkerVersion', c_uint8),
        ('MinorLinkerVersion', c_uint8),
        ('SizeOfCode', c_uint32),
        ('SizeOfInitializedData', c_uint32),
        ('SizeOfUninitializedData', c_uint32),
        ('AddressOfEntryPoint', c_uint32),
        ('BaseOfCode', c_uint32),
        ('BaseOfData', c_uint32),
        ('ImageBase', c_uint32),
        ('SectionAlignment', c_uint32),
        ('FileAlignment', c_uint32),
        ('MajorOperatingSystemVersion', c_uint16),
        ('MinorOperatingSystemVersion', c_uint16),
        ('MajorImageVersion', c_uint16),
        ('MinorImageVersion', c_uint16),
        ('MajorSubsystemVersion', c_uint16),
        ('MinorSubsystemVersion', c_uint16),
        ('Reserved1', c_uint32),
        ('SizeOfImage', c_uint32),
        ('SizeOfHeaders', c_uint32),
        ('CheckSum', c_uint32),
        ('Subsystem', c_uint16),
        ('DllCharacteristics', c_uint16),
        ('SizeOfStackReserve', c_uint32),
        ('SizeOfStackCommit', c_uint32),
        ('SizeOfHeapReserve', c_uint32),
        ('SizeOfHeapCommit', c_uint32),
        ('LoaderFlags', c_uint32),
        ('NumberOfRvaAndSizes', c_uint32), 
    ]
class ImageDataHeader(Structure):
    _fields_ = [
        ('VirtualAddress', c_uint32),
        ('Size', c_uint32),
    ]
    
class ImageSectionHeader(Structure):
     _fields_ = [
        ('name', c_uint8*8),
        #('PhysicalAddress', c_uint32),
        ('VirtualSize', c_uint32),
        ('VirtualAddress', c_uint32),
        ('SizeOfRawData', c_uint32),
        ('PointerToRawData', c_uint32),
        ('PointerToRelocations', c_uint32),
        ('PointerToLinenumbers', c_uint32),
        ('NumberOfRelocations', c_uint16),
        ('NumberOfLinenumbers', c_uint16),
        ('Characteristics', c_uint32),
    ]

class ImportDescUnions(Structure):
     _fields_ = [
		('OriginalFirstThunk', c_uint32),
    ]
    
class ImportDesc(Structure):
    _fields_ = [
		('DUMMY', ImportDescUnions),
		('TimeDateStamp', c_uint32),
		('ForwarderChain',c_uint32),
		('Name', c_uint32),
		('FirstThunk', c_uint32),
	]
    
class ExportDirectoryTable(Structure):   
    _fields_ = [
        ('Characteristics', c_uint32),
        ('TimeDateStamp', c_uint32),
        ('MajorLinkerVersion', c_uint8),
        ('MinorLinkerVersion', c_uint8),
        ('Name', c_uint32),
        ('Base', c_uint32),
        ('NumberOfFunctions', c_uint32),
        ('NumberOfNames', c_uint32),
        ('AddressRVA', c_uint32),
        ('NameRVA', c_uint32),
        ('OrdinalRVA', c_uint32),        
    ]
    
def readString(myfile):
    chars = []
    while True:
        c = myfile.read(1)
        if c == chr(0):
                return "".join(chars)
        chars.append(c)
        
def ReadHex(myfile):
    brojac = 0
    chars = []
    while (brojac < 2):
        c = myfile.read(1)
        brojac +=1
        chars.append(c)
    return "".join(chars)
        

filename = 'pe2.exe'
with open(filename, 'rb') as f:
    res_array = [0] * 4
    res2_array = [0] * 10
    i = 0
    dos = ImageDosHeader()
    f.readinto(dos)
    for num in dos.e_res:
        res_array[i] = num
        i += 1
    res = ''.join(map(str, res_array))
    i = 0
    for num in dos.e_res2:
        res2_array[i] = num
        i += 1
    res2 = ''.join(map(str, res2_array))
    print "MZ header"
    print "==============="
    print ('\t' + "DOS header" + '\t\t' + "{0:#0{1}x}".format(dos.e_magic,6)).expandtabs(10)
    print ('\t' + "Bytes on laste page" + '\t\t' + "{0:#0{1}x}".format(dos.e_cblp,6)).expandtabs(10)
    print ('\t' + "Pages in one file" + '\t\t' + "{0:#0{1}x}".format(dos.e_cp,6)).expandtabs(10)
    print ('\t' + "Relocations" + '\t\t' + "{0:#0{1}x}".format(dos.e_crlc,6)).expandtabs(10)
    print ('\t' + "Size of header" + '\t\t' + "{0:#0{1}x}".format(dos.e_cparhdr,6)).expandtabs(10)
    print ('\t' + "Minimum extra paragraphs need" + '\t' + "{0:#0{1}x}".format(dos.e_minalloc,6)).expandtabs(10)
    print ('\t' + "Maximum extra paragraphs need" + '\t' + "{0:#0{1}x}".format(dos.e_maxalloc,6)).expandtabs(10)
    print ('\t' + "SS pointer" + '\t\t' + "{0:#0{1}x}".format(dos.e_ss,6)).expandtabs(10)
    print ('\t' + "SP pointer" + '\t\t' + "{0:#0{1}x}".format(dos.e_sp,6)).expandtabs(10)
    print ('\t' + "Checksum" + '\t\t\t' + "{0:#0{1}x}".format(dos.e_csum,6)).expandtabs(10)
    print ('\t' + "IP pointer" + '\t\t' + "{0:#0{1}x}".format(dos.e_ip,6)).expandtabs(10)
    print ('\t' + "CS pointer" + '\t\t' + "{0:#0{1}x}".format(dos.e_cs,6)).expandtabs(10)
    print ('\t' + "Address of relocation table" + '\t' + "{0:#0{1}x}".format(dos.e_lfarlc,6)).expandtabs(10)
    print ('\t' + "Overlay" + '\t\t\t' + "{0:#0{1}x}".format(dos.e_ovno,6)).expandtabs(10)
    #print ('\t' + "Reserved" + '\t\t\t' + "{0:#0{1}x}".format(dos.e_res,6)).expandtabs(10)
    print ('\t' + "Reserved" + '\t\t\t' + "0x" + res).expandtabs(10)
    print ('\t' + "OEMID" + '\t\t\t' + "{0:#0{1}x}".format(dos.e_oemid,6)).expandtabs(10)
    print ('\t' + "OEM INFO" + '\t\t\t' + "{0:#0{1}x}".format(dos.e_oeminfo,6)).expandtabs(10)
    print ('\t' + "Reserved 2" + '\t\t' + "0x" + res2).expandtabs(10)
    print ('\t' + "Pointer for PE header " + '\t' + "{0:#0{1}x}".format(dos.e_lfanew,10)).expandtabs(10)
    
    pe = PEHeader()
    f.seek(dos.e_lfanew,0)
    f.readinto(pe)
    if pe.machine != 332:
        print "Application is not 32bit"
        exit()
    print '\n'
    print "PE header"
    print "==============="
    print ('\t' + "PE header" + '\t\t\t' + "{0:#0{1}x}".format(pe.pe_signature,6)).expandtabs(10)
    print ('\t' + "machine" + '\t\t\t' + "{0:#0{1}x}".format(pe.machine,6)).expandtabs(10)
    print ('\t' + "Number of Sections" + '\t\t' + "{0:#0{1}x}".format(pe.sections,6)).expandtabs(10)
    print ('\t' + "Timestamp" + '\t\t\t' + "{0:#0{1}x}".format(pe.timestamp,6)).expandtabs(10)
    print ('\t' + "Symbol pointer" + '\t\t' + "{0:#0{1}x}".format(pe.symbolpointer,8)).expandtabs(10)
    print ('\t' + "Number of symbols" + '\t\t' + "{0:#0{1}x}".format(pe.symbolnumber,8)).expandtabs(10)
    print ('\t' + "Size of optional header" + '\t' + "{0:#0{1}x}".format(pe.sizeofoptional,6)).expandtabs(10)
    print ('\t' + "Characteristics" + '\t\t' + "{0:#0{1}x}".format(pe.characteristics,6)).expandtabs(10)
    
    oh = ImageOptionalHeader()
    f.readinto(oh)

    print "Optional header"
    print "==============="
    print ('\t' + "Optional header" + '\t\t' + "{0:#0{1}x}".format(oh.io_header,6)).expandtabs(10)
    print ('\t' + "MajorLinkerVersion" + '\t\t' + "{0:#0{1}x}".format(oh.MajorLinkerVersion,4)).expandtabs(10)
    print ('\t' + "MinorLinkerVersion" + '\t\t' + "{0:#0{1}x}".format(oh.MinorLinkerVersion,4)).expandtabs(10)
    print ('\t' + "SizeOfCode" + '\t\t' + "{0:#0{1}x}".format(oh.SizeOfCode,10)).expandtabs(10)
    print ('\t' + "SizeOfInitializedData" + '\t' + "{0:#0{1}x}".format(oh.SizeOfInitializedData,10)).expandtabs(10)
    print ('\t' + "SizeOfUninitializedData" + '\t' + "{0:#0{1}x}".format(oh.SizeOfUninitializedData,10)).expandtabs(10)
    print ('\t' + "AddressOfEntryPoint" + '\t\t' + "{0:#0{1}x}".format(oh.AddressOfEntryPoint,10) + '\t' + "RVA - " + "{0:#0{1}x}".format(oh.AddressOfEntryPoint+oh.ImageBase,10)).expandtabs(10)
    print ('\t' + "BaseOfCode" + '\t\t' + "{0:#0{1}x}".format(oh.BaseOfCode,10) + '\t' + "RVA - " + "{0:#0{1}x}".format(oh.BaseOfCode+oh.ImageBase,10)).expandtabs(10)
    print ('\t' + "BaseOfData" + '\t\t' + "{0:#0{1}x}".format(oh.BaseOfData,10) + '\t' + "RVA - " + "{0:#0{1}x}".format(oh.BaseOfData+oh.ImageBase,10)).expandtabs(10)
    print ('\t' + "ImageBase" + '\t\t\t' + "{0:#0{1}x}".format(oh.ImageBase,10)).expandtabs(10)
    print ('\t' + "SectionAlignment" + '\t\t' + "{0:#0{1}x}".format(oh.SectionAlignment,10)).expandtabs(10)
    print ('\t' + "FileAlignment" + '\t\t' + "{0:#0{1}x}".format(oh.FileAlignment,10)).expandtabs(10)
    print ('\t' + "MajorOperatingSystemVersion" + '\t' + "{0:#0{1}x}".format(oh.MajorOperatingSystemVersion,6)).expandtabs(10)
    print ('\t' + "MinorOperatingSystemVersion" + '\t' + "{0:#0{1}x}".format(oh.MinorOperatingSystemVersion,6)).expandtabs(10)
    print ('\t' + "MajorImageVersion" + '\t\t' + "{0:#0{1}x}".format(oh.MajorImageVersion,6)).expandtabs(10)
    print ('\t' + "MinorImageVersion" + '\t\t' + "{0:#0{1}x}".format(oh.MinorImageVersion,6)).expandtabs(10)
    print ('\t' + "MajorSubsystemVersion" + '\t' + "{0:#0{1}x}".format(oh.MajorSubsystemVersion,6)).expandtabs(10)
    print ('\t' + "MinorSubsystemVersion" + '\t' + "{0:#0{1}x}".format(oh.MinorSubsystemVersion,6)).expandtabs(10)
    print ('\t' + "Reserved1" + '\t\t\t' + "{0:#0{1}x}".format(oh.Reserved1,10)).expandtabs(10)
    print ('\t' + "SizeOfImage" + '\t\t' + "{0:#0{1}x}".format(oh.SizeOfImage,10)).expandtabs(10)
    print ('\t' + "SizeOfHeaders" + '\t\t' + "{0:#0{1}x}".format(oh.SizeOfHeaders,10)).expandtabs(10)
    print ('\t' + "CheckSum" + '\t\t\t' + "{0:#0{1}x}".format(oh.CheckSum,10)).expandtabs(10)
    print ('\t' + "Subsystem" + '\t\t\t' + "{0:#0{1}x}".format(oh.Subsystem,6)).expandtabs(10)
    print ('\t' + "DllCharacteristics" + '\t\t' + "{0:#0{1}x}".format(oh.DllCharacteristics,6)).expandtabs(10)
    print ('\t' + "SizeOfStackReserve" + '\t\t' + "{0:#0{1}x}".format(oh.SizeOfStackReserve,10)).expandtabs(10)
    print ('\t' + "SizeOfStackCommit" + '\t\t' + "{0:#0{1}x}".format(oh.SizeOfStackCommit,10)).expandtabs(10)
    print ('\t' + "SizeOfHeapReserve" + '\t\t' + "{0:#0{1}x}".format(oh.SizeOfHeapReserve,10)).expandtabs(10)
    print ('\t' + "SizeOfHeapCommit" + '\t\t' + "{0:#0{1}x}".format(oh.SizeOfHeapCommit,10)).expandtabs(10)
    print ('\t' + "LoaderFlags" + '\t\t' + "{0:#0{1}x}".format(oh.LoaderFlags,10)).expandtabs(10)
    print ('\t' + "NumberOfRvaAndSizes" + '\t\t' + "{0:#0{1}x}".format(oh.NumberOfRvaAndSizes,10)).expandtabs(10)
    
    print '\n'
    print "Data directory table dump"
    print "==============="
    table_names = ['Export Table', 'Import Table', 'Resource Table', 'Exception Table', 'Certificate Table', 'Relocation Table', 'Debug \t', 'Architecture', 'Global Ptr', 'TLS Table\t', 'Load Config Table', 'Bound Import', 'Import Table', 'Import Descriptor', 'CLR Runtime Header', 'Reserved\t']
    for i in range(0, oh.NumberOfRvaAndSizes):
        dh = ImageDataHeader()
        f.readinto(dh)    
        print ('\t' + table_names[i] + '\t\t' + "RVA: " + "{0:#0{1}x}".format(dh.VirtualAddress,10) + '\t' + "Size: " + "{0:#0{1}x}".format(dh.Size,10)).expandtabs(10)
        if (i == 0):
            export_table = dh.VirtualAddress    
            #print export_table
            #raw_input()
        if (i == 1):
            import_table = dh.VirtualAddress
            import_size = dh.Size
            #print import_table
            #print import_size
            #raw_input()

    section_name = [0] * 8
    k = 0
    flag = 0
    print "Section header"
    print "==============="
    for i in range (0, pe.sections):
        j = 0        
        sh = ImageSectionHeader()
        f.readinto(sh)
        for num in sh.name:
            section_name[j] = chr(num)
            j += 1
        #print section_name
        section = ''.join([str(x)for x in section_name]).strip('\x00')
        #print len(section)
        #raw_input()
        print ('\t' + "Name" + '\t\t' + section).expandtabs(10)
        #print ('\t' + "PhysicalAddress" + '\t\t' + "{0:#0{1}x}".format(sh.PhysicalAddress,10)).expandtabs(10)
        print ('\t' + "VirtualSize" + '\t\t' + "{0:#0{1}x}".format(sh.VirtualSize,10)).expandtabs(10)
        print ('\t' + "VirtualAddress" + '\t\t' + "{0:#0{1}x}".format(sh.VirtualAddress,10)).expandtabs(10)
        print ('\t' + "SizeOfRawData" + '\t\t' + "{0:#0{1}x}".format(sh.SizeOfRawData,10)).expandtabs(10)
        print ('\t' + "PointerToRawData" + '\t\t' + "{0:#0{1}x}".format(sh.PointerToRawData,10)).expandtabs(10)
        print ('\t' + "PointerToRelocations" + '\t' + "{0:#0{1}x}".format(sh.PointerToRelocations,10)).expandtabs(10)
        print ('\t' + "PointerToLinenumbers" + '\t' + "{0:#0{1}x}".format(sh.PointerToLinenumbers,10)).expandtabs(10)
        print ('\t' + "NumberOfRelocations" + '\t\t' + "{0:#0{1}x}".format(sh.NumberOfRelocations,10)).expandtabs(10)
        print ('\t' + "NumberOfLinenumbers" + '\t\t' + "{0:#0{1}x}".format(sh.NumberOfLinenumbers,10)).expandtabs(10)
        print ('\t' + "Characteristics" + '\t\t' + "{0:#0{1}x}".format(sh.Characteristics,10)).expandtabs(10) 
        k += 1
        if (section == ".idata" or section == ".rdata"):
            if flag == 1:
                continue
            if section == ".idata":
                flag = 1
            rva = sh.VirtualAddress
            ptr = sh.PointerToRawData
            #print rva
            #print ptr
            #raw_input()
        if (section == ".edata"):
            rva_e = sh.VirtualAddress
            ptr_e = sh.PointerToRawData
        
        
    print "Import  header"
    print "==============="    
    import_address = import_table - rva + ptr
    offset = rva - ptr   
    #print offset
    #print "{0:#0{1}x}".format(import_address,10)
    #raw_input()
    
    im = ImportDesc()
    
    #print im.Name
    #print offset
    #print hex(im.Name - offset)
    f.seek(import_address,0)
    while (1):
        f.readinto(im)
        if (im.Name == 0):
            break
        current_position = f.tell()
        f.seek((im.Name - offset), 0)
        string=readString(f)
        print ('\t' + "OriginalFirstThunk" + '\t\t' + "{0:#0{1}x}".format(im.DUMMY.OriginalFirstThunk,10)).expandtabs(10)
        print ('\t' + "TimeDateStamp" + '\t\t' + "{0:#0{1}x}".format(im.TimeDateStamp,10)).expandtabs(10)
        print ('\t' + "ForwarderChain" + '\t\t' + "{0:#0{1}x}".format(im.ForwarderChain,10)).expandtabs(10)
        print ('\t' + "Name" + '\t\t\t' + "{0:#0{1}x}".format(im.Name,10) + '\t' + string).expandtabs(10) 
        print ('\t' + "FirstThunk" + '\t\t' + "{0:#0{1}x}".format(im.FirstThunk,10)).expandtabs(10) 
        print
        print('\t' + "Functions").expandtabs(10)
        f.seek((im.DUMMY.OriginalFirstThunk-offset), 0)
        while(1):
            #print "U PETLJI SAM"
            #print hex(f.tell())
            array = f.read(4)
            pozicija = f.tell()
            if (array == '\x00\x00\x00\x00'):
                break
            f.seek((struct.unpack('<I', array)[0] - offset), 0)
            string1=ReadHex(f) #paziiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii
            string2=readString(f)
            f.seek(pozicija, 0)
            #print string1
            #print string2
            print ('\t' + hex(struct.unpack('<H', string1[0:2])[0])+ '    ' + string2).expandtabs(10) 
            #raw_input()
        #raw_input("GOTOV DLL")
        f.seek(current_position, 0)
        print '\n\n'
        
    print "Export  header"
    print "==============="    
    export_address = export_table - rva_e + ptr_e
    offset1 = rva_e - ptr_e   # OVAJ OFFSET!!!!!!!!!!!!!!1
    print hex(offset1)
    #print "{0:#0{1}x}".format(export_address,10)
    
    f.seek(export_address, 0)    
    ex = ExportDirectoryTable()
    f.readinto(ex)
    #print ex.Characteristics
    #print hex(ex.AddressRVA)
    print ('\t' + "Characteristics" + '\t\t' + "{0:#0{1}x}".format(ex.Characteristics,10)).expandtabs(10)
    print ('\t' + "TimeDateStamp" + '\t\t' + "{0:#0{1}x}".format(ex.TimeDateStamp,10)).expandtabs(10)
    print ('\t' + "MajorLinkerVersion" + '\t\t' + "{0:#0{1}x}".format(ex.MajorLinkerVersion,10)).expandtabs(10)
    print ('\t' + "MinorLinkerVersion" + '\t\t' + "{0:#0{1}x}".format(ex.MinorLinkerVersion,10)).expandtabs(10)
    print ('\t' + "Name" + '\t\t\t' + "{0:#0{1}x}".format(ex.Name,10)).expandtabs(10)
    print ('\t' + "Base" + '\t\t\t' + "{0:#0{1}x}".format(ex.Base,10)).expandtabs(10)
    print ('\t' + "NumberOfFunctions" + '\t\t' + "{0:#0{1}x}".format(ex.NumberOfFunctions,10)).expandtabs(10)
    print ('\t' + "NumberOfNames" + '\t\t' + "{0:#0{1}x}".format(ex.NumberOfNames,10)).expandtabs(10)
    print ('\t' + "AddressRVA" + '\t\t' + "{0:#0{1}x}".format(ex.AddressRVA,10)).expandtabs(10)
    print ('\t' + "NameRVA" + '\t\t\t' + "{0:#0{1}x}".format(ex.NameRVA,10)).expandtabs(10)
    print ('\t' + "OrdinalRVA" + '\t\t' + "{0:#0{1}x}".format(ex.OrdinalRVA,10)).expandtabs(10)
'''
    print hex(ex.AddressRVA - offset1)
    print hex(ex.NameRVA - offset1)
    print hex(ex.OrdinalRVA - offset1)
    raw_input()
    for i in range (0, ex.NumberOfFunctions):
        f.seek(ex.AddressRVA - offset1, 0)
        array = f.read(4)
        pozicija = f.tell()
        
        print i

    raw_input()
 
    while (1):
        f.readinto(im)
        if (im.Name == 0):
            break
        current_position = f.tell()
        f.seek((im.Name - offset), 0)
        string=readString(f)
        print ('\t' + "OriginalFirstThunk" + '\t\t' + "{0:#0{1}x}".format(im.DUMMY.OriginalFirstThunk,10)).expandtabs(10)
        print ('\t' + "TimeDateStamp" + '\t\t' + "{0:#0{1}x}".format(im.TimeDateStamp,10)).expandtabs(10)
        print ('\t' + "ForwarderChain" + '\t\t' + "{0:#0{1}x}".format(im.ForwarderChain,10)).expandtabs(10)
        print ('\t' + "Name" + '\t\t\t' + "{0:#0{1}x}".format(im.Name,10) + '\t' + string).expandtabs(10) 
        print ('\t' + "FirstThunk" + '\t\t' + "{0:#0{1}x}".format(im.FirstThunk,10)).expandtabs(10) 
        print
        print('\t' + "Functions").expandtabs(10)
        f.seek((im.DUMMY.OriginalFirstThunk-offset), 0)
        while(1):
            #print "U PETLJI SAM"
            #print hex(f.tell())
            array = f.read(4)
            pozicija = f.tell()
            if (array == '\x00\x00\x00\x00'):
                break
            f.seek((struct.unpack('<I', array)[0] - offset), 0)
            string1=ReadHex(f)
            string2=readString(f)
            f.seek(pozicija, 0)
            #print string1
            #print string2
            print ('\t' + hex(struct.unpack('<H', string1[0:2])[0])+ '    ' + string2).expandtabs(10) 
            #raw_input()
        #raw_input("GOTOV DLL")
        f.seek(current_position, 0)
        print '\n\n'
    
    print hex(f.tell())
'''    


    
    
    
    
    
    
    
    
	

