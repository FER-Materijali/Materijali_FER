from ctypes import *
import struct

class ImageDosHeader(Structure):
    _fields_ = [
        ('e_magic', c_uint16),
        ('e_cblp', c_uint16),
        ('e_cp', c_uint16),
        ('e_crlc', c_uint16),
        ('e_cparhdr', c_uint16),
        ('e_minalloc', c_uint16),
        ('e_maxalloc', c_uint16),
        ('e_ss', c_uint16),
        ('e_sp', c_uint16),
        ('e_csum', c_uint16),
        ('e_ip', c_uint16),
        ('e_cs', c_uint16),
        ('e_lfarlc', c_uint16),
        ('e_ovno', c_uint16),
        ('e_res', c_uint16 * 4),
        ('e_oemid', c_uint16),
        ('e_oeminfo', c_uint16),
        ('e_res2', c_uint16 * 10),
        ('e_lfanew', c_uint32),
    ]
    
class PEHeader(Structure):   
    _fields_ = [
        ('pe_signature', c_uint32),
        ('machine', c_uint16),
        ('sections', c_uint16),
        ('timestamp', c_uint32),
        ('symbolpointer', c_uint32),
        ('symbolnumber', c_uint32),
        ('sizeofoptional', c_uint16),
        ('characteristics', c_uint16),
    ]
    
class ImageOptionalHeader(Structure):   
    _fields_ = [
        ('io_header', c_uint16),
        ('MajorLinkerVersion', c_uint8),
        ('MinorLinkerVersion', c_uint8),
        ('SizeOfCode', c_uint32),
        ('SizeOfInitializedData', c_uint32),
        ('SizeOfUninitializedData', c_uint32),
        ('AddressOfEntryPoint', c_uint32),
        ('BaseOfCode', c_uint32),
        ('BaseOfData', c_uint32),
        ('ImageBase', c_uint32),
        ('SectionAlignment', c_uint32),
        ('FileAlignment', c_uint32),
        ('MajorOperatingSystemVersion', c_uint16),
        ('MinorOperatingSystemVersion', c_uint16),
        ('MajorImageVersion', c_uint16),
        ('MinorImageVersion', c_uint16),
        ('MajorSubsystemVersion', c_uint16),
        ('MinorSubsystemVersion', c_uint16),
        ('Reserved1', c_uint32),
        ('SizeOfImage', c_uint32),
        ('SizeOfHeaders', c_uint32),
        ('CheckSum', c_uint32),
        ('Subsystem', c_uint16),
        ('DllCharacteristics', c_uint16),
        ('SizeOfStackReserve', c_uint32),
        ('SizeOfStackCommit', c_uint32),
        ('SizeOfHeapReserve', c_uint32),
        ('SizeOfHeapCommit', c_uint32),
        ('LoaderFlags', c_uint32),
        ('NumberOfRvaAndSizes', c_uint32), 
    ]
class ImageDataHeader(Structure):
    _fields_ = [
        ('VirtualAddress', c_uint32),
        ('Size', c_uint32),
        
    ]
    
class ImageSectionHeader(Structure):
     _fields_ = [
        ('name', c_uint8*8),
        #('PhysicalAddress', c_uint32),
        ('VirtualSize', c_uint32),
        ('VirtualAddress', c_uint32),
        ('SizeOfRawData', c_uint32),
        ('PointerToRawData', c_uint32),
        ('PointerToRelocations', c_uint32),
        ('PointerToLinenumbers', c_uint32),
        ('NumberOfRelocations', c_uint16),
        ('NumberOfLinenumbers', c_uint16),
        ('Characteristics', c_uint32),
    ]

class ImportDesc(Structure):
     _fields_ = [
        ('dwRVAFunctionNameList', c_ulong),
        ('dwUseless1', c_ulong),
        ('dwUseless2', c_ulong),
        ('dwRVAModuleName', c_ulong),
        ('dwRVAFunctionAddressList', c_ulong),
        ('test1', c_ulong),
        ('test2', c_ulong),
        ('test3', c_ulong),
        ('test4', c_ulong),
        ('test5', c_ulong),
    ]


filename = 'pe.exe'
with open(filename, 'rb') as f:
    res_array = [0] * 4
    res2_array = [0] * 10
    i = 0
    dos = ImageDosHeader()
    f.readinto(dos)
    for num in dos.e_res:
        res_array[i] = num
        i += 1
    res = ''.join(map(str, res_array))
    i = 0
    for num in dos.e_res2:
        res2_array[i] = num
        i += 1
    res2 = ''.join(map(str, res2_array))
    print "MZ header"
    print "==============="
    print ('\t' + "DOS header" + '\t\t' + "{0:#0{1}x}".format(dos.e_magic,6)).expandtabs(10)
    print ('\t' + "Bytes on laste page" + '\t\t' + "{0:#0{1}x}".format(dos.e_cblp,6)).expandtabs(10)
    print ('\t' + "Pages in one file" + '\t\t' + "{0:#0{1}x}".format(dos.e_cp,6)).expandtabs(10)
    print ('\t' + "Relocations" + '\t\t' + "{0:#0{1}x}".format(dos.e_crlc,6)).expandtabs(10)
    print ('\t' + "Size of header" + '\t\t' + "{0:#0{1}x}".format(dos.e_cparhdr,6)).expandtabs(10)
    print ('\t' + "Minimum extra paragraphs need" + '\t' + "{0:#0{1}x}".format(dos.e_minalloc,6)).expandtabs(10)
    print ('\t' + "Maximum extra paragraphs need" + '\t' + "{0:#0{1}x}".format(dos.e_maxalloc,6)).expandtabs(10)
    print ('\t' + "SS pointer" + '\t\t' + "{0:#0{1}x}".format(dos.e_ss,6)).expandtabs(10)
    print ('\t' + "SP pointer" + '\t\t' + "{0:#0{1}x}".format(dos.e_sp,6)).expandtabs(10)
    print ('\t' + "Checksum" + '\t\t\t' + "{0:#0{1}x}".format(dos.e_csum,6)).expandtabs(10)
    print ('\t' + "IP pointer" + '\t\t' + "{0:#0{1}x}".format(dos.e_ip,6)).expandtabs(10)
    print ('\t' + "CS pointer" + '\t\t' + "{0:#0{1}x}".format(dos.e_cs,6)).expandtabs(10)
    print ('\t' + "Address of relocation table" + '\t' + "{0:#0{1}x}".format(dos.e_lfarlc,6)).expandtabs(10)
    print ('\t' + "Overlay" + '\t\t\t' + "{0:#0{1}x}".format(dos.e_ovno,6)).expandtabs(10)
    #print ('\t' + "Reserved" + '\t\t\t' + "{0:#0{1}x}".format(dos.e_res,6)).expandtabs(10)
    print ('\t' + "Reserved" + '\t\t\t' + "0x" + res).expandtabs(10)
    print ('\t' + "OEMID" + '\t\t\t' + "{0:#0{1}x}".format(dos.e_oemid,6)).expandtabs(10)
    print ('\t' + "OEM INFO" + '\t\t\t' + "{0:#0{1}x}".format(dos.e_oeminfo,6)).expandtabs(10)
    print ('\t' + "Reserved 2" + '\t\t' + "0x" + res2).expandtabs(10)
    print ('\t' + "Pointer for PE header " + '\t' + "{0:#0{1}x}".format(dos.e_lfanew,10)).expandtabs(10)
    
    pe = PEHeader()
    f.seek(dos.e_lfanew,0)
    f.readinto(pe)
    if pe.machine != 332:
        print "Application is not 32bit"
        exit()
    print '\n'
    print "PE header"
    print "==============="
    print ('\t' + "PE header" + '\t\t\t' + "{0:#0{1}x}".format(pe.pe_signature,6)).expandtabs(10)
    print ('\t' + "machine" + '\t\t\t' + "{0:#0{1}x}".format(pe.machine,6)).expandtabs(10)
    print ('\t' + "Number of Sections" + '\t\t' + "{0:#0{1}x}".format(pe.sections,6)).expandtabs(10)
    print ('\t' + "Timestamp" + '\t\t\t' + "{0:#0{1}x}".format(pe.timestamp,6)).expandtabs(10)
    print ('\t' + "Symbol pointer" + '\t\t' + "{0:#0{1}x}".format(pe.symbolpointer,8)).expandtabs(10)
    print ('\t' + "Number of symbols" + '\t\t' + "{0:#0{1}x}".format(pe.symbolnumber,8)).expandtabs(10)
    print ('\t' + "Size of optional header" + '\t' + "{0:#0{1}x}".format(pe.sizeofoptional,6)).expandtabs(10)
    print ('\t' + "Characteristics" + '\t\t' + "{0:#0{1}x}".format(pe.characteristics,6)).expandtabs(10)
    
    oh = ImageOptionalHeader()
    f.readinto(oh)

    print "Optional header"
    print "==============="
    print ('\t' + "Optional header" + '\t\t' + "{0:#0{1}x}".format(oh.io_header,6)).expandtabs(10)
    print ('\t' + "MajorLinkerVersion" + '\t\t' + "{0:#0{1}x}".format(oh.MajorLinkerVersion,4)).expandtabs(10)
    print ('\t' + "MinorLinkerVersion" + '\t\t' + "{0:#0{1}x}".format(oh.MinorLinkerVersion,4)).expandtabs(10)
    print ('\t' + "SizeOfCode" + '\t\t' + "{0:#0{1}x}".format(oh.SizeOfCode,10)).expandtabs(10)
    print ('\t' + "SizeOfInitializedData" + '\t' + "{0:#0{1}x}".format(oh.SizeOfInitializedData,10)).expandtabs(10)
    print ('\t' + "SizeOfUninitializedData" + '\t' + "{0:#0{1}x}".format(oh.SizeOfUninitializedData,10)).expandtabs(10)
    print ('\t' + "AddressOfEntryPoint" + '\t\t' + "{0:#0{1}x}".format(oh.AddressOfEntryPoint,10) + '\t' + "RVA - " + "{0:#0{1}x}".format(oh.AddressOfEntryPoint+oh.ImageBase,10)).expandtabs(10)
    print ('\t' + "BaseOfCode" + '\t\t' + "{0:#0{1}x}".format(oh.BaseOfCode,10) + '\t' + "RVA - " + "{0:#0{1}x}".format(oh.BaseOfCode+oh.ImageBase,10)).expandtabs(10)
    print ('\t' + "BaseOfData" + '\t\t' + "{0:#0{1}x}".format(oh.BaseOfData,10) + '\t' + "RVA - " + "{0:#0{1}x}".format(oh.BaseOfData+oh.ImageBase,10)).expandtabs(10)
    print ('\t' + "ImageBase" + '\t\t\t' + "{0:#0{1}x}".format(oh.ImageBase,10)).expandtabs(10)
    print ('\t' + "SectionAlignment" + '\t\t' + "{0:#0{1}x}".format(oh.SectionAlignment,10)).expandtabs(10)
    print ('\t' + "FileAlignment" + '\t\t' + "{0:#0{1}x}".format(oh.FileAlignment,10)).expandtabs(10)
    print ('\t' + "MajorOperatingSystemVersion" + '\t' + "{0:#0{1}x}".format(oh.MajorOperatingSystemVersion,6)).expandtabs(10)
    print ('\t' + "MinorOperatingSystemVersion" + '\t' + "{0:#0{1}x}".format(oh.MinorOperatingSystemVersion,6)).expandtabs(10)
    print ('\t' + "MajorImageVersion" + '\t\t' + "{0:#0{1}x}".format(oh.MajorImageVersion,6)).expandtabs(10)
    print ('\t' + "MinorImageVersion" + '\t\t' + "{0:#0{1}x}".format(oh.MinorImageVersion,6)).expandtabs(10)
    print ('\t' + "MajorSubsystemVersion" + '\t' + "{0:#0{1}x}".format(oh.MajorSubsystemVersion,6)).expandtabs(10)
    print ('\t' + "MinorSubsystemVersion" + '\t' + "{0:#0{1}x}".format(oh.MinorSubsystemVersion,6)).expandtabs(10)
    print ('\t' + "Reserved1" + '\t\t\t' + "{0:#0{1}x}".format(oh.Reserved1,10)).expandtabs(10)
    print ('\t' + "SizeOfImage" + '\t\t' + "{0:#0{1}x}".format(oh.SizeOfImage,10)).expandtabs(10)
    print ('\t' + "SizeOfHeaders" + '\t\t' + "{0:#0{1}x}".format(oh.SizeOfHeaders,10)).expandtabs(10)
    print ('\t' + "CheckSum" + '\t\t\t' + "{0:#0{1}x}".format(oh.CheckSum,10)).expandtabs(10)
    print ('\t' + "Subsystem" + '\t\t\t' + "{0:#0{1}x}".format(oh.Subsystem,6)).expandtabs(10)
    print ('\t' + "DllCharacteristics" + '\t\t' + "{0:#0{1}x}".format(oh.DllCharacteristics,6)).expandtabs(10)
    print ('\t' + "SizeOfStackReserve" + '\t\t' + "{0:#0{1}x}".format(oh.SizeOfStackReserve,10)).expandtabs(10)
    print ('\t' + "SizeOfStackCommit" + '\t\t' + "{0:#0{1}x}".format(oh.SizeOfStackCommit,10)).expandtabs(10)
    print ('\t' + "SizeOfHeapReserve" + '\t\t' + "{0:#0{1}x}".format(oh.SizeOfHeapReserve,10)).expandtabs(10)
    print ('\t' + "SizeOfHeapCommit" + '\t\t' + "{0:#0{1}x}".format(oh.SizeOfHeapCommit,10)).expandtabs(10)
    print ('\t' + "LoaderFlags" + '\t\t' + "{0:#0{1}x}".format(oh.LoaderFlags,10)).expandtabs(10)
    print ('\t' + "NumberOfRvaAndSizes" + '\t\t' + "{0:#0{1}x}".format(oh.NumberOfRvaAndSizes,10)).expandtabs(10)
    
    print '\n'
    print "Data directory table dump"
    print "==============="
    table_names = ['Export Table', 'Import Table', 'Resource Table', 'Exception Table', 'Certificate Table', 'Relocation Table', 'Debug \t', 'Architecture', 'Global Ptr', 'TLS Table\t', 'Load Config Table', 'Bound Import', 'Import Table', 'Import Descriptor', 'CLR Runtime Header', 'Reserved\t']
    for i in range(0, oh.NumberOfRvaAndSizes):
        dh = ImageDataHeader()
        f.readinto(dh)    
        print ('\t' + table_names[i] + '\t\t' + "RVA: " + "{0:#0{1}x}".format(dh.VirtualAddress,10) + '\t' + "Size: " + "{0:#0{1}x}".format(dh.Size,10)).expandtabs(10)

    section_name = [0] * 8
    print "Section header"
    print "==============="
    for i in range (0, pe.sections):
        i = 0
        sh = ImageSectionHeader()
        f.readinto(sh)
        for num in sh.name:
            section_name[i] = chr(num)
            i += 1
        section = ''.join([str(x)for x in section_name])
        print ('\t' + "Name" + '\t\t' + section).expandtabs(10)
        #print ('\t' + "PhysicalAddress" + '\t\t' + "{0:#0{1}x}".format(sh.PhysicalAddress,10)).expandtabs(10)
        print ('\t' + "VirtualSize" + '\t\t' + "{0:#0{1}x}".format(sh.VirtualSize,10)).expandtabs(10)
        print ('\t' + "VirtualAddress" + '\t\t' + "{0:#0{1}x}".format(sh.VirtualAddress,10)).expandtabs(10)
        print ('\t' + "SizeOfRawData" + '\t\t' + "{0:#0{1}x}".format(sh.SizeOfRawData,10)).expandtabs(10)
        print ('\t' + "PointerToRawData" + '\t\t' + "{0:#0{1}x}".format(sh.PointerToRawData,10)).expandtabs(10)
        print ('\t' + "PointerToRelocations" + '\t' + "{0:#0{1}x}".format(sh.PointerToRelocations,10)).expandtabs(10)
        print ('\t' + "PointerToLinenumbers" + '\t' + "{0:#0{1}x}".format(sh.PointerToLinenumbers,10)).expandtabs(10)
        print ('\t' + "NumberOfRelocations" + '\t\t' + "{0:#0{1}x}".format(sh.NumberOfRelocations,10)).expandtabs(10)
        print ('\t' + "NumberOfLinenumbers" + '\t\t' + "{0:#0{1}x}".format(sh.NumberOfLinenumbers,10)).expandtabs(10)
        print ('\t' + "Characteristics" + '\t\t' + "{0:#0{1}x}".format(sh.Characteristics,10)).expandtabs(10)
       
    

        
    


    
    

    
   
    
    
    
   

    
    

    
    
    
    
    
    
    
    
	

