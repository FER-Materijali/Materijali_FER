syms s KRkr Tr w real;

Gr = KRkr;
Gp1 = 2/(1 + s + 2*s*s);
Gp2 = 1/(1 + 10*s);
Go = Gr*Gp1*Gp2;
Go = subs (Go, s, j*2*pi/Tr);
pretty(Go);
[KRkr Tr] = solve (abs(Go) == 1, imag(Go)/real(Go));
KRkr = vpa (KRkr(1,1))
Tr = vpa(Tr(1,1))

KrPI = 0.45 * KRkr
TrPI = 0.85*Tr
KrPID = 0.6 * KRkr
TrPID = 0.5*Tr
TdPID = 0.12*Tr