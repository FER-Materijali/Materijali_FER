syms w Kr Ti Td T real
Kr = 1.68;
Ti = 4.2361;
Td = 1.0166;

Gr = Kr *(1 + 1/(Ti*s) + Td*s/(0.2*s + 1));
Gp1 = 2/(1 + s + 2*s*s);
Gp2 = 1/(1 + 10*s);
Go = simplify(Gr*Gp1*Gp2)
Go = subs (Go, s, j*w);
w = solve(sqrt((real(Go))^2 + (imag(Go))^2) == 1, w)
w = w(1,1);
T = (0.34 + 0.17)/2 / w;
T = double (T)

[n d] = numden (Gr);
n = sym2poly (n);
d = sym2poly (d);
Gr = tf(n, d)
sysd = c2d(Gr, T, 'tustin')