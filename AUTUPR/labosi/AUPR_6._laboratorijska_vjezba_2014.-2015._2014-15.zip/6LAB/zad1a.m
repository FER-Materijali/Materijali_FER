syms s Kr T1 real;

Gr = Kr *(1 + 1/(T1*s));
Gp1 = 2/(1 + s + 2*s*s);
Gp2 = 1/(1 + 10*s);
Go = Gr*Gp1*Gp2;
R = 1/s;
E = R/(1 + Go);
[n d] = numden (E)
E = (n/d);
pretty (E)

d = coeffs(d, s)
n = coeffs (n, s)

c0=n(1,1);
c1=n(1,2);
c2=n(1,3);
c3=n(1,4);
d0=d(1,1);
d1=d(1,2);
d2=d(1,3);
d3=d(1,4);
d4=d(1,5);
Ibr=(c3^2*(-d0^2*d3+d0*d1*d2)+(c2^2-2*c1*c3)*d0*d1*d4+(c1^2-2*c0*c2)*d0*d3*d4+c0^2*(-d1*d4^2+d2*d3*d4));
Inaz=2*d0*d4*(-d0*d3^2-d1^2*d4+d1*d2*d3);
I= simplify (Ibr/Inaz);
pretty(I)
[Kr T1]=solve(diff(I,T1),diff(I,Kr), Kr, T1);
Kr=double(Kr)
T1=double(T1)

